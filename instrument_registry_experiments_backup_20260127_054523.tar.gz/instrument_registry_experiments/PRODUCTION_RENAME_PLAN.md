# Instrument Registry Production Rename Plan

## Overview

This document outlines the systematic approach to rename `instrument_registry_experiments` to `instrument_registry` for production deployment.

## Phase 1: Code and API Changes

### 1.1 Python Package Renaming
- [ ] Rename root directory: `instrument_registry_experiments/` → `instrument_registry/`
- [ ] Update all import statements from `instrument_registry_experiments.*` to `instrument_registry.*`
- [ ] Update `setup.py` or `pyproject.toml` package name

### 1.2 API Router Updates
- [ ] Change router prefix: `/api/v1/internal/instrument-registry-experiments` → `/api/v1/internal/instrument-registry`
- [ ] Update FastAPI app title: "Instrument Registry Experiments API" → "Instrument Registry API"
- [ ] Update service name in health endpoint response

### 1.3 Configuration Key Updates
```python
# Old
INSTRUMENT_REGISTRY_EXPERIMENTS_DATABASE_URL
INSTRUMENT_REGISTRY_EXPERIMENTS_API_URL
INSTRUMENT_REGISTRY_EXPERIMENTS_API_KEY
INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG

# New
INSTRUMENT_REGISTRY_DATABASE_URL
INSTRUMENT_REGISTRY_API_URL
INSTRUMENT_REGISTRY_API_KEY
# Remove mock config flag entirely
```

### 1.4 Service Name Updates
- [ ] `app/config.py`: Change `SERVICE_NAME = "instrument_registry_experiments"` to `SERVICE_NAME = "instrument_registry"`
- [ ] Update logging contexts
- [ ] Update metrics labels

## Phase 2: Database Schema Migration

### 2.1 Schema Renaming
```sql
-- Create new schema
CREATE SCHEMA IF NOT EXISTS instrument_registry;

-- Migrate types
CREATE TYPE instrument_registry.asset_class_enum AS ENUM (
    SELECT unnest(enum_range(NULL::instrument_registry_experiments.asset_class_enum))
);
-- Repeat for all custom types

-- Migrate tables with data
CREATE TABLE instrument_registry.instrument_keys AS 
SELECT * FROM instrument_registry_experiments.instrument_keys;

-- Add constraints and indexes
-- ... (copy all constraints)

-- Set up dual-write triggers for transition period
```

### 2.2 Migration Scripts
- [ ] Create `migrations/rename_to_production/001_create_new_schema.sql`
- [ ] Create `migrations/rename_to_production/002_migrate_data.sql`
- [ ] Create `migrations/rename_to_production/003_setup_dual_write.sql`
- [ ] Create `migrations/rename_to_production/004_cleanup_old_schema.sql`

## Phase 3: Implementation of Stubbed Features

### 3.1 Ingestion Endpoint
Replace the 501 stub in `POST /brokers/{broker_id}/ingest` with:
```python
async def ingest_broker_data(
    broker_id: str,
    request: IngestRequest,
    db: AsyncSession = Depends(get_db)
):
    # Implement real ingestion logic
    # 1. Validate broker exists
    # 2. Queue ingestion job
    # 3. Return job ID for tracking
```

### 3.2 Remove Mock Fallbacks
- [ ] Remove `app/mock_config.py`
- [ ] Remove `INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG` checks
- [ ] Ensure calendar integration fails fast if calendar service unavailable

## Phase 4: Infrastructure Updates

### 4.1 Docker and Compose Files
- [ ] Update image names: `instrument-registry-experiments` → `instrument-registry`
- [ ] Update container names
- [ ] Update volume names
- [ ] Remove hardcoded ports, use port registry

### 4.2 Kubernetes Manifests
- [ ] Update deployment names
- [ ] Update service names
- [ ] Update configmap/secret references
- [ ] Update namespace if needed

### 4.3 Port Registry Integration
```yaml
# Add to config_service.port_registry
- service_name: instrument_registry
  port: 8084
  protocol: http
  description: "Instrument Registry API"
```

## Phase 5: Documentation Updates

### 5.1 Files to Update
- [ ] `FOUNDATION_PATH_FORWARD.md`
- [ ] `CALENDAR_MIGRATION_GUIDE.md`
- [ ] `QUICK_REFERENCE_CARD.md`
- [ ] `PRODUCTION_GO_LIVE_CHECKLIST.md`
- [ ] `GO_LIVE_COMMANDS.md`
- [ ] All README files

### 5.2 Content Updates
- Replace all instances of "experiments" with production terms
- Update command examples
- Update configuration examples
- Update API endpoint examples

## Phase 6: Testing and Validation

### 6.1 Update Test Fixtures
- [ ] Update test database names
- [ ] Update test configuration
- [ ] Update API client tests

### 6.2 Run Validation Suites
```bash
# After renaming
python scripts/production_dryrun_validation.py
python scripts/exercise_recovery_procedures.py
python scripts/validate_event_replay.py
```

## Migration Execution Order

1. **Preparation Phase**
   - Create migration scripts
   - Set up dual-write capability
   - Prepare rollback plan

2. **Database Migration**
   - Create new schema
   - Set up dual-write triggers
   - Migrate existing data

3. **Code Deployment**
   - Deploy renamed service with dual-read capability
   - Verify functionality
   - Monitor for issues

4. **Cutover**
   - Switch reads to new schema
   - Disable dual-write after verification
   - Clean up old schema (after backup)

## Rollback Plan

1. Code rollback: Deploy previous version
2. Database rollback: Switch back to old schema (dual-write ensures data consistency)
3. Configuration rollback: Restore old environment variables

## Success Criteria

- [ ] All endpoints respond with new paths
- [ ] No references to "experiments" in production code
- [ ] All tests pass with new naming
- [ ] Metrics and logs use new service name
- [ ] Calendar integration works without fallbacks
- [ ] Real ingestion endpoint functional
- [ ] Documentation reflects production state