# Order Service Proxy Cache

This proxy keeps the experimental registry from touching `order_service` by caching broker tokens in a lightweight table while still serving the familiar `instrument_token` shape via `instrument_registry_experiments.order_service_instrument_tokens` view.

## Setup
1. Configure the following keys in the config service:
   - `INSTRUMENT_REGISTRY_EXPERIMENTS_API_URL`: Base URL of the experimental registry API (e.g., ``http://localhost:8000/api/v1/internal/instrument-registry-experiments``)
   - `INSTRUMENT_REGISTRY_EXPERIMENTS_API_KEY`: Internal API key used to call the registry.
   - `INSTRUMENT_REGISTRY_PROXY_DEFAULT_BROKER`: Broker ID (e.g., `kite`) for order_service traffic.
   - `INSTRUMENT_REGISTRY_PROXY_WATCHED_INSTRUMENTS`: JSON array of the instruments to keep cached.
   - `INSTRUMENT_REGISTRY_PROXY_REFRESH_INTERVAL_SECONDS`: (Optional) Refresh interval, defaults to 300.

2. The JSON payload for watched instruments should look like:
```json
[
  {
    "instrument_key": "NFO@NIFTY@options@2025-05-15@call@19500",
    "symbol": "NIFTY",
    "exchange": "NFO",
    "broker_id": "kite"
  }
]
   ```

To run the experiment without a real config service, set the environment variable `INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG=1`. The mock client ships with sane defaults and can be customized via `MOCK_CONFIG_<KEY>` and `MOCK_SECRET_<KEY>` environment variables (e.g., `MOCK_CONFIG_INSTRUMENT_REGISTRY_PROXY_WATCHED_INSTRUMENTS`). This is ideal for local experimentation before you wire up an actual config service.
## Running the proxy
Execute the refresh loop from the repository root:
```
python -m instrument_registry_experiments.proxy.run_proxy
```
It will repeatedly call the experimental registry APIs, upsert tokens into `instrument_token_cache`, and keep the `order_service_instrument_tokens` view current.

To monitor the cache, run the proxy health endpoint:

```
uvicorn instrument_registry_experiments.proxy.health:app --reload --port 8081
```

Then poll `http://localhost:8081/health` to see the last refresh time, total cached tokens, and whether the cache is stale.

## Order service integration
Point the existing order_service lookup to the `order_service_instrument_tokens` view (configured via its database URL) or expose a small HTTP endpoint that reads from the view. No code changes in `order_service` are required; the proxy keeps returning the same `instrument_token` data it expects.

When the experiment proves reliable, you can skip the proxy and let `order_service` call the registry APIs directly.
