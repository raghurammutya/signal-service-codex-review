# Instrument Registry Experiments API Spec

## Overview
This experimental service owns the `instrument_registry_experiments` schema and exposes internal APIs that:
- resolve canonical instrument keys across exchanges, asset classes, and brokers
- surface broker-specific tokens for historical/backtest lookups
- provide strike interval intelligence derived from exchange data
- accept broker-provided instrument registries and ingestion metadata

Each endpoint requires internal authentication (API keys or service-to-service tokens) similar to ticker_service internal routes.

## Endpoints

### 1. `POST /api/v1/internal/instrument-registry-experiments/brokers/{broker_id}/ingest`
Accepts a broker payload and upserts instrument records.

**Request**
```json
{
  "records": [
    {
      "symbol": "NIFTY",
      "exchange": "NFO",
      "asset_class": "option",
      "instrument_type": "CE",
      "expiry": "2025-05-15",
      "strike": 19500,
      "lot_size": 25,
      "tick_size": 0.05,
      "currency": "INR",
      "broker_token": "12345",
      "valid_from": "2025-05-01",
      "valid_to": "2025-05-15",
      "metadata": {
        "margin": 1250.0
      }
    }
  ],
  "source_media": "api"
}
```

**Response**
```json
{
  "created": 42,
  "updated": 7,
  "failed": []
}
```

### 2. `GET /api/v1/internal/instrument-registry-experiments/resolve`
Resolves symbol/expiry metadata to a canonical instrument key and broker coverage.

**Query Parameters**
- `symbol` (required)
- `exchange` (required)
- `expiry` (optional)
- `instrument_type` (optional)
- `asset_class` (optional)
- `broker_id` (optional)
- `as_of` (optional date)

**Response**
```json
{
  "instrument_key": "NIFTY@NFO@NFO-OPT@option@2025-05-15@19500",
  "metadata": { ... },
  "available_brokers": [
    {
      "broker_id": "kite",
      "tokens": [ { "token": "12345", "valid_from": "2025-05-01", "valid_to": "2025-05-15" } ]
    }
  ]
}
```

### 3. `GET /api/v1/internal/instrument-registry-experiments/brokers/{broker_id}/token`
Returns broker token(s) for a given instrument key and date (defaults to today).

**Query Parameters**
- `instrument_key` (required)
- `as_of` (optional date)

**Response**
```json
{
  "broker_token": "12345",
  "valid_from": "2025-05-01",
  "valid_to": "2025-05-15",
  "lot_size": 25,
  "strike": 19500,
  "instrument_status": "active"
}
```

### 4. `GET /api/v1/internal/instrument-registry-experiments/strike-intelligence`
Provides exchange-specific strike spacing and expiry intelligence.

**Parameters**
- `instrument_key`
- `expiry_date`
- `distance_from_atm`
- `as_of` (optional)

**Response**
```json
{
  "expiry_type": "weekly",
  "distance_tier": "near",
  "strike_interval": 25,
  "density": "dense",
  "atm_reference": 19550,
  "strikes_available": [19300, 19325, ...]
}
```

### 5. `GET /api/v1/internal/instrument-registry-experiments/history`
Returns instrument snapshots for historical/backtest usage.

**Parameters**
- `instrument_key`
- `from_date`
- `to_date`
- `broker_id` (optional)

**Response**
```json
{
  "snapshots": [
    {
      "date": "2025-05-01",
      "lot_size": 25,
      "strike": 19500,
      "metadata": {"exchange_notes": "lot change"},
      "exists": true
    }
  ]
}
```

### Asset Metadata

All registry responses now surface richer metadata so every asset class can be described:

- `asset_subclass` captures classifications such as `weekly_option`, `perp`, or `bond_tranche`.
- `pair_base`/`pair_quote` combined with `is_pair` describe FX and crypto pairs even without a traditional exchange code.
- `quote_currency`, `settlement_currency`, `issuer`, and `fund_house` capture bonds/mutual funds/OTC layers.
- `is_mutual_fund` flags fund-only instruments that don’t trade on the usual exchanges.

This metadata travels with every `instrument_key`, letting downstream services infer lot sizes, strike distances, and settlement conventions irrespective of the originating broker.

### 6. `GET /api/v1/internal/instrument-registry-experiments/brokers`
Lists configured broker feeds and ingestion metadata (useful for orchestration dashboards).

### 7. `GET /api/v1/internal/instrument-registry-experiments/brokers/{broker_id}`
Returns ingestion configuration, supported asset classes, and last sync status.

### Security & Config
- Each endpoint requires the same internal API key trust as `ticker_service` internal routes.
- Config service stores broker registry endpoints, authentication secrets, supported asset classes, and ingestion cadence.
- Strike intelligence defaults can also be seeded from config_service until automated ingestion is available.

This spec enables downstream services (order_service, algo_engine, signal_service, etc.) to consume broker-neutral instrument metadata before migrating the logic back into ticker_service.
