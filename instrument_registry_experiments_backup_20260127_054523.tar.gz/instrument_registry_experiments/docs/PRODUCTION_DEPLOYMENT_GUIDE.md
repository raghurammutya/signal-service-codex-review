# Instrument Registry Production Deployment Guide

## Overview

This guide covers the deployment of the production-ready Instrument Registry service, formerly known as instrument_registry_experiments.

## Prerequisites

- Kubernetes cluster with Istio service mesh
- PostgreSQL 14+ with partitioning support
- Redis 7+ for caching
- Config service deployed and accessible
- Calendar service deployed and accessible
- Message service deployed and accessible
- Event store deployed and accessible

## Migration from Experiments

### Step 1: Database Migration

```bash
# 1. Create production schema
psql -U postgres -d instrument_registry < migrations/rename_to_production/001_create_new_schema.sql

# 2. Migrate data with dual-write
psql -U postgres -d instrument_registry < migrations/rename_to_production/002_migrate_data.sql
psql -U postgres -d instrument_registry < migrations/rename_to_production/003_setup_dual_write.sql

# 3. Verify migration
psql -U postgres -d instrument_registry -c "
SELECT 
    'instrument_registry_experiments' as schema,
    COUNT(*) as count 
FROM instrument_registry_experiments.instrument_keys
UNION ALL
SELECT 
    'instrument_registry' as schema,
    COUNT(*) as count 
FROM instrument_registry.instrument_keys;"
```

### Step 2: Deploy Production Service

```bash
# 1. Build production image
docker build -f Dockerfile.production -t instrument-registry:latest .

# 2. Push to registry
docker tag instrument-registry:latest your-registry/instrument-registry:latest
docker push your-registry/instrument-registry:latest

# 3. Deploy to Kubernetes
kubectl apply -f k8s/instrument-registry-production.yaml

# 4. Wait for rollout
kubectl rollout status deployment/instrument-registry -n instrument-registry
```

### Step 3: Configure Service

```bash
# 1. Register with config service
curl -X POST http://config-service:8080/api/v1/services \
  -H "Content-Type: application/json" \
  -d '{
    "service_name": "instrument_registry",
    "config": {
      "database_url": "postgresql://user:pass@postgres:5432/instrument_registry",
      "calendar_service_url": "http://calendar-service:8081",
      "message_service_url": "http://message-service:8082",
      "event_store_url": "postgresql://user:pass@postgres:5432/event_store",
      "cache_ttl_seconds": 300,
      "ingestion_batch_size": 1000
    }
  }'

# 2. Register port in port registry
INSERT INTO config_service.port_registry (service_name, port, protocol, description)
VALUES ('instrument_registry', 8084, 'http', 'Instrument Registry API');
```

### Step 4: Validate Deployment

```bash
# Run validation script
python scripts/validate_production_rename.py

# Check endpoints
curl http://instrument-registry:8084/health
curl http://instrument-registry:8084/api/v1/internal/instrument-registry/brokers

# Test ingestion endpoint
curl -X POST http://instrument-registry:8084/api/v1/internal/instrument-registry/brokers/kite/ingest \
  -H "X-Internal-API-Key: ${INTERNAL_API_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"mode": "INCREMENTAL", "filters": {}}'
```

## Production Configuration

### Environment Variables (Bootstrap Only)

```yaml
ENVIRONMENT: production
CONFIG_SERVICE_URL: http://config-service:8080
INTERNAL_API_KEY: <from-secret>
```

### Config Service Keys

```json
{
  "instrument_registry": {
    "database": {
      "url": "postgresql://instrument_user:password@postgres:5432/instrument_registry",
      "pool_size": 10,
      "max_overflow": 20
    },
    "services": {
      "calendar_service_url": "http://calendar-service:8081",
      "calendar_service_api_key": "<from-secret>",
      "message_service_url": "http://message-service:8082",
      "message_service_api_key": "<from-secret>",
      "event_store_url": "postgresql://event_user:password@postgres:5432/event_store"
    },
    "cache": {
      "redis_url": "redis://redis:6379/0",
      "ttl_seconds": 300
    },
    "ingestion": {
      "batch_size": 1000,
      "worker_count": 4,
      "queue_url": "redis://redis:6379/1"
    }
  }
}
```

## API Changes

### Old Endpoints (Deprecated)
- `/api/v1/internal/instrument-registry-experiments/*`

### New Endpoints
- `/api/v1/internal/instrument-registry/*`

All functionality remains the same, only the path prefix has changed.

## Monitoring and Alerts

### Prometheus Metrics
```yaml
# Ingestion metrics
instrument_registry_ingestion_total{broker="kite",status="success|failed"}
instrument_registry_ingestion_duration_seconds{broker="kite"}

# API metrics
instrument_registry_api_requests_total{endpoint="/resolve",status="200"}
instrument_registry_api_latency_seconds{endpoint="/resolve"}

# Cache metrics
instrument_registry_cache_hits_total
instrument_registry_cache_misses_total
```

### Grafana Dashboard
Import dashboard from `monitoring/dashboards/instrument-registry.json`

### Alerts
```yaml
- alert: InstrumentRegistryDown
  expr: up{job="instrument-registry"} == 0
  for: 5m
  
- alert: InstrumentRegistryHighErrorRate
  expr: rate(instrument_registry_api_requests_total{status=~"5.."}[5m]) > 0.05
  for: 10m
  
- alert: InstrumentRegistrySlowIngestion
  expr: instrument_registry_ingestion_duration_seconds > 300
  for: 15m
```

## Rollback Procedure

If issues arise during deployment:

```bash
# 1. Switch back to old service
kubectl scale deployment instrument-registry -n instrument-registry --replicas=0
kubectl scale deployment instrument-registry-experiments -n default --replicas=3

# 2. Database is safe due to dual-write
# No action needed

# 3. Revert configuration if needed
# Update config service to use old keys
```

## Post-Deployment Cleanup

After successful validation (recommended: 1 week):

```bash
# 1. Remove dual-write triggers
psql -U postgres -d instrument_registry < migrations/rename_to_production/004_cleanup_old_schema.sql

# 2. Archive old schema
pg_dump -U postgres -d instrument_registry -n instrument_registry_experiments > experiments_backup.sql

# 3. Drop old schema (after backup verified)
psql -U postgres -d instrument_registry -c "DROP SCHEMA instrument_registry_experiments CASCADE;"

# 4. Remove old deployment
kubectl delete deployment instrument-registry-experiments -n default
```

## Troubleshooting

### Service Won't Start
- Check logs: `kubectl logs -n instrument-registry deployment/instrument-registry`
- Verify config service is accessible
- Check database connectivity

### API Returns 404
- Verify correct path prefix: `/api/v1/internal/instrument-registry`
- Check service is registered in Istio

### Ingestion Fails
- Check broker credentials in database
- Verify calendar service is accessible
- Check Redis queue connectivity

## Success Criteria

- [ ] All health checks passing
- [ ] API endpoints responding with correct paths
- [ ] No references to "experiments" in logs
- [ ] Ingestion jobs completing successfully
- [ ] Metrics flowing to Prometheus
- [ ] No errors in first 24 hours