<!--
High-level foundation improvement plan for the instrument registry experiment.
-->

# Foundation Improvement Plan

This document captures the critique and recommended foundation rebuild so the registry can support every asset class, broker token variation, and downstream workflow in production.

## 1. Canonical Key Hierarchy
- Replace the current delimited string with a structured hierarchy:  
  `asset_class:asset_type:venue:identifier:contract`.  
- Always include the asset class, and only emit the relevant dimensions for the type (no `@null@`).  
- Provide helper functions per asset class (equity, crypto, bond, fund, forex, commodity) so each can generate and parse the canonical key deterministically.

## 2. Normalized Metadata Model
- Split `instrument_keys` into a slim `instruments` master table plus asset-specific extension tables (equities, crypto, bonds, funds, commodities, indexes).  
- Capture asset-specific metadata (exchange/segment for equities, pair_base/quote for crypto/forex, issuer/fund_house for bonds/funds, settlement/contract size for commodities).  
- Drop redundant flags (`is_pair`, `is_mutual_fund`) and derive them from the asset-class tables.
 
## 3. Event-Sourced History + States
- Store every instrument change as an event (`instrument_events`): creation, adjustment, corporate action, regulatory change, broker update.  
- Materialize current states and time slices in `instrument_states` (effective from/to, lot/tick/margin/settlement).  
- Provide read models optimized for backtests and analytics while keeping the write model consistent.

## 4. Strike Intelligence Redesign
- Replace the current simple table with a `strike_patterns` catalog that encodes: expiry type, volatility regime, liquidity tier, base interval, interval multipliers, psychological levels, valid date range, and optional funding tiers for perps.  
- Store multiple patterns per underlying so we can answer questions like “what strike spacing should I use for NIFTY weekly near the ATM?” or “what are the psychological levels for gold options on MCX?”

## 5. Broker Token Mapping
- Introduce a multi-dimensional `broker_instrument_mappings` table that records broker_id, instrument_key, token_type (market_data/order), account_tier, API version, broker_symbol, token, validity window, and metadata.  
- Allow multiple rows per broker/instrument so we can model token reuse, account-specific mappings, and multi-leg strategies.

## 6. Workflow-Oriented APIs
- Add workflow endpoints (`POST /instruments/resolve/bulk`, `GET /strikes/chain/{underlying}/current`, `GET /brokers/compare?instruments=...`, `POST /portfolio/risk/calculate`, `WebSocket /instruments/updates`).  
- Expose optional query parameters to request only the metadata needed (e.g., `fields=pair,lot`).  
- Publish change events so services can subscribe to updates instead of polling.

## 7. Consistency & Scaling
- Apply optimistic locking/conflict detection on bridge tables (instrument definitions, token mappings).  
- Implement cache invalidation & notification strategies (streaming events, WebSocket).  
- Partition historical data and build CQRS read models tailored to query patterns (order simulation, strike lookup, risk aggregate).  
- Document availability expectations and failover behavior for real-time trading.

## 8. Next Steps
1. Draft the normalized schema (master + asset-specific tables + event store + states).  
2. Define ingestion adapters to populate the asset-specific metadata.  
3. Expand the API layer per the workflow requirements and add health/monitoring for consistency.  
4. Build tooling (migrations, validation scripts, mock data) to facilitate the new architecture.
