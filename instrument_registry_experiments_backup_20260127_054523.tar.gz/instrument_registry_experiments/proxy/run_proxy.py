"""Runs the instrument token cache proxy refresh loop."""

import asyncio
import logging

from app.proxy.cache_service import InstrumentTokenCacheService
from app.proxy.config import ProxyConfig

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main() -> None:
    config = ProxyConfig()
    service = InstrumentTokenCacheService(config)
    while True:
        try:
            await service.refresh()
        except Exception as exc:
            logger.exception("Proxy cache refresh failed: %s", exc)
        await asyncio.sleep(config.refresh_interval_seconds)


if __name__ == "__main__":
    asyncio.run(main())
