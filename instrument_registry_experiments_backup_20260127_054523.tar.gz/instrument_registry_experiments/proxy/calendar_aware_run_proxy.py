"""Calendar-aware instrument token cache proxy refresh loop."""

import asyncio
import logging
from typing import Dict, Optional
from datetime import datetime

from app.proxy.cache_service import InstrumentTokenCacheService
from app.proxy.calendar_config import CalendarAwareProxyConfig

# Import calendar integration if available
try:
    from common.calendar_client import CalendarServiceClient, MarketState
    CALENDAR_AVAILABLE = True
except ImportError:
    CALENDAR_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning("Calendar service integration not available, falling back to time-based scheduling")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CalendarAwareProxyService:
    """Proxy service with calendar awareness."""
    
    def __init__(self, config: CalendarAwareProxyConfig):
        self.config = config
        self.service = InstrumentTokenCacheService(config)
        self.calendar_client: Optional[CalendarServiceClient] = None
        
        # Initialize calendar client if available
        if CALENDAR_AVAILABLE and config.calendar_enabled:
            self.calendar_client = CalendarServiceClient(
                config.calendar_service_url,
                config.calendar_api_key
            )
            logger.info("Calendar service integration enabled")
        else:
            logger.info("Running in time-based mode (calendar service not configured)")
    
    async def get_market_states(self) -> Dict[str, str]:
        """Get current market states for all monitored exchanges."""
        if not self.calendar_client:
            return {}
        
        states = {}
        try:
            async with self.calendar_client:
                for exchange in self.config.monitored_exchanges:
                    try:
                        state = await self.calendar_client.get_market_state(exchange)
                        states[exchange] = state.state.value
                    except Exception as e:
                        logger.error(f"Failed to get {exchange} state: {e}")
                        states[exchange] = "UNKNOWN"
        except Exception as e:
            logger.error(f"Calendar service error: {e}")
            
        return states
    
    def determine_refresh_interval(self, market_states: Dict[str, str]) -> int:
        """Determine refresh interval based on market states."""
        if not market_states:
            # No calendar data, use fallback
            return self.config.fallback_interval_seconds
        
        # Use the most active market state
        state_priority = {
            "OPEN": 1,
            "PRE_MARKET": 2,
            "POST_MARKET": 3,
            "CLOSED": 4,
            "WEEKEND": 5,
            "HOLIDAY": 6,
            "UNKNOWN": 7,
        }
        
        most_active_state = min(
            market_states.values(),
            key=lambda s: state_priority.get(s, 999)
        )
        
        return self.config.get_refresh_interval_for_state(most_active_state)
    
    async def should_refresh_now(self, market_states: Dict[str, str]) -> bool:
        """Check if refresh should happen based on configuration and market state."""
        # Always refresh if calendar not available
        if not market_states:
            return True
        
        # Check if any market is in a state we should refresh for
        active_states = {"OPEN", "PRE_MARKET", "POST_MARKET"}
        any_active = any(state in active_states for state in market_states.values())
        
        # Skip if markets are open and we don't refresh during market hours
        if not self.config.refresh_during_market_hours and any(
            state == "OPEN" for state in market_states.values()
        ):
            logger.info("Skipping refresh - markets are open")
            return False
        
        # Skip holidays if configured
        if self.config.skip_holidays and all(
            state == "HOLIDAY" for state in market_states.values()
        ):
            logger.info("Skipping refresh - market holiday")
            return False
        
        # Skip weekends if configured  
        if self.config.skip_weekends and all(
            state == "WEEKEND" for state in market_states.values()
        ):
            logger.info("Skipping refresh - weekend")
            return False
        
        # Check if we're in preferred window (only for non-active states)
        if not any_active:
            current_hour = datetime.utcnow().hour
            in_preferred_window = any(
                start <= current_hour < end
                for start, end in self.config.preferred_refresh_windows
            )
            if not in_preferred_window:
                logger.info("Not in preferred refresh window")
                return False
        
        return True
    
    async def run(self):
        """Main refresh loop with calendar awareness."""
        while True:
            try:
                # Get current market states
                market_states = await self.get_market_states()
                
                if market_states:
                    logger.info(f"Market states: {market_states}")
                
                # Check if we should refresh
                if await self.should_refresh_now(market_states):
                    logger.info("Refreshing instrument cache...")
                    await self.service.refresh()
                else:
                    logger.debug("Skipping refresh based on market conditions")
                
                # Determine next check interval
                interval = self.determine_refresh_interval(market_states)
                logger.info(f"Next check in {interval} seconds")
                
                await asyncio.sleep(interval)
                
            except Exception as exc:
                logger.exception("Proxy cache refresh failed: %s", exc)
                # Use fallback interval on error
                await asyncio.sleep(self.config.fallback_interval_seconds)


async def main() -> None:
    """Main entry point."""
    config = CalendarAwareProxyConfig()
    service = CalendarAwareProxyService(config)
    await service.run()


if __name__ == "__main__":
    asyncio.run(main())