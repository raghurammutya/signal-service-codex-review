"""Health endpoint for proxy cache service."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel

from app.db import get_db_pool

app = FastAPI(title="Instrument Registry Proxy Health")


class HealthResponse(BaseModel):
    status: str
    last_refreshed: Optional[datetime]
    token_count: int
    stale: bool


@app.get("/health", response_model=HealthResponse)
async def health():
    pool = await get_db_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT MAX(last_refreshed) AS last_refreshed, COUNT(*) AS token_count
            FROM instrument_registry_experiments.instrument_token_cache
            """
        )

    last_refreshed = row["last_refreshed"]
    token_count = row["token_count"] or 0
    stale = False
    if last_refreshed:
        from datetime import timezone
        now_utc = datetime.now(timezone.utc)
        if last_refreshed.tzinfo is None:
            # Make naive datetime timezone-aware (assume UTC)
            last_refreshed = last_refreshed.replace(tzinfo=timezone.utc)
        stale = now_utc - last_refreshed > timedelta(minutes=10)

    status = "healthy" if last_refreshed and not stale else "stale"
    return HealthResponse(
        status=status,
        last_refreshed=last_refreshed,
        token_count=token_count,
        stale=stale,
    )
