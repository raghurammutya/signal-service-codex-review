"""Calendar-aware health endpoint for proxy cache service."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional, Dict

from fastapi import FastAPI
from pydantic import BaseModel

from app.db import get_db_pool
from app.proxy.calendar_config import CalendarAwareProxyConfig

# Import calendar integration if available
try:
    from common.calendar_client import CalendarServiceClient, MarketState
    CALENDAR_AVAILABLE = True
except ImportError:
    CALENDAR_AVAILABLE = False

app = FastAPI(title="Instrument Registry Proxy Health (Calendar-Aware)")

# Global calendar client
calendar_client: Optional[CalendarServiceClient] = None
config = CalendarAwareProxyConfig()

if CALENDAR_AVAILABLE and config.calendar_enabled:
    calendar_client = CalendarServiceClient(
        config.calendar_service_url,
        config.calendar_api_key
    )


class CalendarAwareHealthResponse(BaseModel):
    status: str
    last_refreshed: Optional[datetime]
    token_count: int
    stale: bool
    market_states: Dict[str, str]
    staleness_threshold_minutes: int
    reason: Optional[str]


async def get_market_aware_staleness_threshold() -> int:
    """Get staleness threshold based on current market state."""
    if not calendar_client:
        return 10  # Default 10 minutes
    
    try:
        async with calendar_client:
            # Check market states
            any_market_open = False
            all_markets_closed = True
            is_holiday = False
            is_weekend = False
            
            for exchange in config.monitored_exchanges:
                try:
                    state = await calendar_client.get_market_state(exchange)
                    
                    if state.state == MarketState.OPEN:
                        any_market_open = True
                        all_markets_closed = False
                    elif state.state in [MarketState.PRE_MARKET, MarketState.POST_MARKET]:
                        all_markets_closed = False
                    elif state.state == MarketState.HOLIDAY:
                        is_holiday = True
                    elif state.state == MarketState.WEEKEND:
                        is_weekend = True
                except:
                    pass
            
            # Determine threshold based on market state
            if any_market_open:
                return 5  # 5 minutes during market hours
            elif not all_markets_closed:  # Pre/Post market
                return 15  # 15 minutes
            elif is_weekend:
                return 120  # 2 hours on weekends
            elif is_holiday:
                return 60  # 1 hour on holidays
            else:
                return 30  # 30 minutes when markets closed
                
    except Exception:
        return 10  # Fallback to default
    
    return 10


async def get_current_market_states() -> Dict[str, str]:
    """Get current market states for all exchanges."""
    if not calendar_client:
        return {}
    
    states = {}
    try:
        async with calendar_client:
            for exchange in config.monitored_exchanges:
                try:
                    state = await calendar_client.get_market_state(exchange)
                    states[exchange] = state.state.value
                except Exception:
                    states[exchange] = "UNKNOWN"
    except Exception:
        pass
    
    return states


@app.get("/health", response_model=CalendarAwareHealthResponse)
async def calendar_aware_health():
    """Health check with market-aware staleness detection."""
    pool = await get_db_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT MAX(last_refreshed) AS last_refreshed, COUNT(*) AS token_count
            FROM instrument_registry_experiments.instrument_token_cache
            """
        )

    last_refreshed = row["last_refreshed"]
    token_count = row["token_count"] or 0
    
    # Get market states
    market_states = await get_current_market_states()
    
    # Get appropriate staleness threshold
    staleness_threshold = await get_market_aware_staleness_threshold()
    
    # Check staleness
    stale = False
    reason = None
    
    if last_refreshed:
        now_utc = datetime.now(timezone.utc)
        if last_refreshed.tzinfo is None:
            # Make naive datetime timezone-aware (assume UTC)
            last_refreshed = last_refreshed.replace(tzinfo=timezone.utc)
        
        minutes_since_refresh = (now_utc - last_refreshed).total_seconds() / 60
        stale = minutes_since_refresh > staleness_threshold
        
        if stale:
            reason = f"Last refresh was {minutes_since_refresh:.1f} minutes ago (threshold: {staleness_threshold} minutes)"
    else:
        stale = True
        reason = "No refresh timestamp found"

    # Determine status
    if not last_refreshed:
        status = "unhealthy"
    elif stale:
        # Check if staleness is acceptable given market state
        if market_states and all(
            state in ["WEEKEND", "HOLIDAY", "CLOSED"] 
            for state in market_states.values()
        ):
            status = "healthy"  # Staleness is OK during non-trading periods
            reason = "Cache staleness acceptable during non-trading period"
        else:
            status = "stale"
    else:
        status = "healthy"
    
    return CalendarAwareHealthResponse(
        status=status,
        last_refreshed=last_refreshed,
        token_count=token_count,
        stale=stale,
        market_states=market_states,
        staleness_threshold_minutes=staleness_threshold,
        reason=reason
    )