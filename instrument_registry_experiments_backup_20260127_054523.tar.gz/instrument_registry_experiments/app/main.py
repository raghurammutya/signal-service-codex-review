"""Main FastAPI application for Instrument Registry Experiments."""
from fastapi import FastAPI
from .api.instrument_registry import router as instrument_registry_router

app = FastAPI(
    title="Instrument Registry Experiments API",
    description="Experimental API for instrument registry with broker token mapping",
    version="1.0.0"
)

# Include the instrument registry router
app.include_router(instrument_registry_router)

@app.get("/")
async def root():
    return {"message": "Instrument Registry Experiments API", "status": "running"}

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "instrument_registry_experiments"}