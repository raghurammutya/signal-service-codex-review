"""Database helpers for the instrument registry experiments schema."""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

import asyncpg

from .config import ExperimentConfig

logger = logging.getLogger(__name__)

_db_pool: Optional[asyncpg.Pool] = None
_pool_lock = asyncio.Lock()


async def get_db_pool() -> asyncpg.Pool:
    global _db_pool

    if _db_pool:
        return _db_pool

    async with _pool_lock:
        if _db_pool:
            return _db_pool
        config = ExperimentConfig()
        _db_pool = await asyncpg.create_pool(config.database_url, max_size=10)
        logger.info("Connected to experiment schema database")
        return _db_pool


async def close_db_pool() -> None:
    global _db_pool
    if _db_pool:
        await _db_pool.close()
        _db_pool = None
