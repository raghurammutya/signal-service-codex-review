"""Proxy configuration helpers for the instrument registry cache."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from ..config import ExperimentConfig, _get_config_value, _get_secret_value  # pylint: disable=protected-access

logger = logging.getLogger(__name__)


class ProxyConfig(ExperimentConfig):
    """Configuration for the order_service proxy cache."""

    def __init__(self) -> None:
        super().__init__()
        self.registry_api_url = _get_config_value("INSTRUMENT_REGISTRY_EXPERIMENTS_API_URL")
        self.registry_api_key = _get_secret_value("INSTRUMENT_REGISTRY_EXPERIMENTS_API_KEY")
        self.default_broker_id = _get_config_value("INSTRUMENT_REGISTRY_PROXY_DEFAULT_BROKER")
        self.refresh_interval_seconds = int(
            _get_config_value("INSTRUMENT_REGISTRY_PROXY_REFRESH_INTERVAL_SECONDS", required=False)
            or 300
        )

        instruments_json = _get_config_value("INSTRUMENT_REGISTRY_PROXY_WATCHED_INSTRUMENTS", required=False)
        if instruments_json:
            try:
                parsed = json.loads(instruments_json)
                if isinstance(parsed, list):
                    self.watched_instruments = parsed
                else:
                    raise ValueError("Instrument list must be an array of objects")
            except ValueError as exc:
                logger.warning("Invalid watched instruments config: %s", exc)
                self.watched_instruments = []
        else:
            self.watched_instruments = []

    def get_watched(self) -> List[Dict[str, Any]]:
        return self.watched_instruments
