"""Calendar-aware proxy configuration for the instrument registry cache."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from .config import ProxyConfig, _get_config_value, _get_secret_value

logger = logging.getLogger(__name__)


@dataclass
class CalendarAwareProxyConfig(ProxyConfig):
    """Enhanced configuration with calendar service integration."""
    
    # Calendar service settings
    calendar_service_url: Optional[str] = None
    calendar_api_key: Optional[str] = None
    
    # Market-aware refresh settings
    refresh_during_market_hours: bool = True
    skip_holidays: bool = True
    skip_weekends: bool = True
    
    # Preferred refresh windows (in market timezone)
    preferred_refresh_windows: List[Tuple[int, int]] = field(default_factory=lambda: [
        (2, 6),    # 2 AM - 6 AM
        (22, 24),  # 10 PM - Midnight
    ])
    
    # Exchanges to monitor
    monitored_exchanges: List[str] = field(default_factory=lambda: ["NSE", "BSE"])
    
    # Fallback to time-based if calendar service unavailable
    fallback_interval_seconds: int = 300
    calendar_service_timeout: int = 5  # seconds
    
    # Different intervals for different market states
    market_open_interval_seconds: int = 60      # 1 minute during market
    pre_market_interval_seconds: int = 180      # 3 minutes pre-market
    post_market_interval_seconds: int = 300     # 5 minutes post-market
    closed_market_interval_seconds: int = 1800  # 30 minutes when closed
    holiday_interval_seconds: int = 3600        # 1 hour on holidays
    
    def __init__(self) -> None:
        """Initialize calendar-aware configuration."""
        super().__init__()
        
        # Load calendar service config
        self.calendar_service_url = _get_config_value(
            "CALENDAR_SERVICE_URL", 
            required=False
        )
        self.calendar_api_key = _get_secret_value(
            "CALENDAR_SERVICE_API_KEY",
            required=False
        )
        
        # Load market-aware settings
        self.refresh_during_market_hours = _get_config_value(
            "INSTRUMENT_REGISTRY_REFRESH_DURING_MARKET",
            required=False
        ) != "false"
        
        self.skip_holidays = _get_config_value(
            "INSTRUMENT_REGISTRY_SKIP_HOLIDAYS",
            required=False
        ) != "false"
        
        self.skip_weekends = _get_config_value(
            "INSTRUMENT_REGISTRY_SKIP_WEEKENDS",
            required=False
        ) != "false"
        
        # Load monitored exchanges
        exchanges_json = _get_config_value(
            "INSTRUMENT_REGISTRY_MONITORED_EXCHANGES",
            required=False
        )
        if exchanges_json:
            try:
                self.monitored_exchanges = json.loads(exchanges_json)
            except json.JSONDecodeError:
                logger.warning("Invalid monitored exchanges config, using defaults")
        
        # Load interval overrides
        if market_open := _get_config_value("INSTRUMENT_REGISTRY_MARKET_OPEN_INTERVAL", required=False):
            self.market_open_interval_seconds = int(market_open)
        
        if pre_market := _get_config_value("INSTRUMENT_REGISTRY_PRE_MARKET_INTERVAL", required=False):
            self.pre_market_interval_seconds = int(pre_market)
            
        if post_market := _get_config_value("INSTRUMENT_REGISTRY_POST_MARKET_INTERVAL", required=False):
            self.post_market_interval_seconds = int(post_market)
            
        if closed := _get_config_value("INSTRUMENT_REGISTRY_CLOSED_MARKET_INTERVAL", required=False):
            self.closed_market_interval_seconds = int(closed)
            
        if holiday := _get_config_value("INSTRUMENT_REGISTRY_HOLIDAY_INTERVAL", required=False):
            self.holiday_interval_seconds = int(holiday)
    
    @property
    def calendar_enabled(self) -> bool:
        """Check if calendar service is configured."""
        return bool(self.calendar_service_url)
    
    def get_refresh_interval_for_state(self, market_state: str) -> int:
        """Get appropriate refresh interval based on market state."""
        intervals = {
            "OPEN": self.market_open_interval_seconds,
            "PRE_MARKET": self.pre_market_interval_seconds,
            "POST_MARKET": self.post_market_interval_seconds,
            "CLOSED": self.closed_market_interval_seconds,
            "HOLIDAY": self.holiday_interval_seconds,
            "WEEKEND": self.holiday_interval_seconds,
        }
        return intervals.get(market_state, self.fallback_interval_seconds)