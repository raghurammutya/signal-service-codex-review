"""Token cache service for order_service proxy."""

from __future__ import annotations

import logging
from datetime import date
from typing import Dict, Optional

from ..db import get_db_pool
from .client import InstrumentRegistryExplorerClient
from .config import ProxyConfig

logger = logging.getLogger(__name__)


class InstrumentTokenCacheService:
    def __init__(self, config: ProxyConfig) -> None:
        self.config = config

    async def refresh(self) -> None:
        watched = self.config.get_watched()
        if not watched:
            logger.warning("No instruments configured for proxy cache refresh")
            return

        client = InstrumentRegistryExplorerClient(self.config)
        pool = await get_db_pool()
        try:
            async with pool.acquire() as conn:
                for instrument in watched:
                    broker_id = instrument.get("broker_id") or self.config.default_broker_id
                    instrument_key = instrument.get("instrument_key")
                    if not instrument_key or not broker_id:
                        logger.warning("Skipping instrument with missing key/broker: %s", instrument)
                        continue

                    token_info = await client.fetch_broker_token(instrument_key, broker_id)
                    if not token_info:
                        logger.warning("No token returned for %s@%s", instrument_key, broker_id)
                        continue

                    await self._upsert_cache(conn, instrument, broker_id, token_info)
        finally:
            await client.close()

    async def _upsert_cache(
        self,
        conn,
        instrument: Dict[str, str],
        broker_id: str,
        token_info: Dict[str, any],
    ) -> None:
        instrument_key = instrument["instrument_key"]
        token = token_info.get("token")
        if not token:
            logger.warning("Token payload missing token field: %s", token_info)
            return

        valid_from = _parse_date(token_info.get("valid_from")) or date.today()
        valid_to = _parse_date(token_info.get("valid_to"))
        attributes = token_info.get("attributes") or {}

        metadata = {
            "symbol": instrument.get("symbol"),
            "exchange": instrument.get("exchange"),
            "broker": broker_id,
            **attributes,
        }

        await conn.execute(
            """
            INSERT INTO instrument_registry_experiments.instrument_token_cache (
                broker_id, instrument_key, instrument_token,
                valid_from, valid_to, lot_size, strike, metadata, last_refreshed
            ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,now())
            ON CONFLICT (broker_id, instrument_key, valid_from) DO UPDATE SET
                instrument_token = EXCLUDED.instrument_token,
                valid_to = EXCLUDED.valid_to,
                lot_size = EXCLUDED.lot_size,
                strike = EXCLUDED.strike,
                metadata = EXCLUDED.metadata,
                last_refreshed = now()
            """,
            broker_id,
            instrument_key,
            token,
            valid_from,
            valid_to,
            token_info.get("lot_size"),
            token_info.get("strike"),
            metadata,
        )


def _parse_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        logger.warning("Unable to parse date from %s", value)
        return None
