"""HTTP client for the instrument registry experiments APIs."""

from __future__ import annotations

from datetime import date
from typing import Optional

import httpx

from .config import ProxyConfig


class InstrumentRegistryExplorerClient:
    def __init__(self, config: ProxyConfig) -> None:
        self._client = httpx.AsyncClient(
            base_url=config.registry_api_url,
            headers={"X-Internal-API-Key": config.registry_api_key},
            timeout=10.0,
        )
        self._config = config

    async def fetch_broker_token(
        self,
        instrument_key: str,
        broker_id: str,
        as_of: Optional[date] = None,
    ) -> Optional[dict]:
        params = {"instrument_key": instrument_key}
        if as_of:
            params["as_of"] = as_of.isoformat()
        response = await self._client.get(f"/brokers/{broker_id}/token", params=params)
        response.raise_for_status()
        data = response.json()
        # Expecting structure: {"broker_id":..., "tokens":[...]}
        tokens = data.get("tokens") or []
        return tokens[0] if tokens else None

    async def close(self) -> None:
        await self._client.aclose()
