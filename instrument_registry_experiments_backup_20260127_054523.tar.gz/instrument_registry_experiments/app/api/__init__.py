"""API modules for the instrument registry experiment service."""
from .instrument_registry import router

__all__ = ["router"]
