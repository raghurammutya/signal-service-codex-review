"""API scaffolding for the Instrument Registry Experiments service."""
from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, HTTPException, Path, Query

from ..db import get_db_pool

router = APIRouter(prefix="/api/v1/internal/instrument-registry-experiments", tags=["instrument-registry-experiments"])


@router.post("/brokers/{broker_id}/ingest")
async def ingest_broker_registry(
    broker_id: str = Path(..., description="Broker identifier"),
    records: List[Dict[str, Any]] = Body(..., description="Payload containing normalized instrument records"),
) -> Dict[str, Any]:
    raise HTTPException(status_code=501, detail="Ingestion adapter not implemented yet")


@router.get("/resolve")
async def resolve_instrument(
    symbol: str = Query(...),
    exchange: str = Query(...),
    expiry: Optional[str] = Query(None),
    instrument_type: Optional[str] = Query(None),
    asset_class: Optional[str] = Query(None),
    broker_id: Optional[str] = Query(None),
    as_of: Optional[str] = Query(None),
) -> Dict[str, Any]:
    expiry_date = _parse_date(expiry)
    as_of_date = _parse_date(as_of)

    pool = await get_db_pool()
    async with pool.acquire() as conn:
        instrument = await _fetch_instrument_row(
            conn,
            symbol=symbol,
            exchange=exchange,
            instrument_type=instrument_type,
            asset_class=asset_class,
            expiry=expiry_date,
            broker_id=broker_id,
        )

        if not instrument:
            raise HTTPException(status_code=404, detail="Instrument not found")

        available_brokers = await _fetch_available_brokers(conn, instrument["id"], as_of_date)

    return {
        "instrument_key": instrument["instrument_key"],
        "symbol": instrument["symbol"],
        "exchange": instrument["exchange"],
        "segment": instrument["segment"],
        "asset_class": instrument["asset_class"],
        "asset_subclass": instrument["asset_subclass"],
        "pair_base": instrument["pair_base"],
        "pair_quote": instrument["pair_quote"],
        "quote_currency": instrument["quote_currency"],
        "settlement_currency": instrument["settlement_currency"],
        "issuer": instrument["issuer"],
        "fund_house": instrument["fund_house"],
        "is_pair": instrument["is_pair"],
        "is_mutual_fund": instrument["is_mutual_fund"],
        "instrument_type": instrument["instrument_type"],
        "expiry": instrument["expiry"].isoformat() if instrument["expiry"] else None,
        "strike": instrument["strike"],
        "lot_size": float(instrument["lot_size"]) if instrument["lot_size"] else None,
        "tick_size": float(instrument["tick_size"]) if instrument["tick_size"] else None,
        "metadata": instrument["metadata"],
        "available_brokers": available_brokers,
    }


@router.get("/brokers/{broker_id}/token")
async def lookup_broker_token(
    broker_id: str = Path(...),
    instrument_key: str = Query(...),
    as_of: Optional[str] = Query(None),
) -> Dict[str, Any]:
    as_of_date = _parse_date(as_of)

    pool = await get_db_pool()
    async with pool.acquire() as conn:
        instrument = await _fetch_instrument_by_key(conn, instrument_key)
        if not instrument:
            raise HTTPException(status_code=404, detail="Instrument key not found")

        tokens = await _fetch_available_brokers(
            conn,
            instrument["id"],
            as_of_date,
            broker_filter=broker_id,
        )

    if not tokens:
        raise HTTPException(status_code=404, detail="No token found for broker/instrument combination")

    return tokens[0]


@router.get("/strike-intelligence")
async def strike_intelligence(
    instrument_key: str = Query(...),
    expiry_date: Optional[str] = Query(None),
    distance_from_atm: Optional[float] = Query(None),
    as_of: Optional[str] = Query(None),
) -> Dict[str, Any]:
    instrument_date = _parse_date(expiry_date)
    as_of_date = _parse_date(as_of)

    pool = await get_db_pool()
    async with pool.acquire() as conn:
        instrument = await _fetch_instrument_by_key(conn, instrument_key)
        if not instrument:
            raise HTTPException(status_code=404, detail="Instrument key not found")

        rows = await _fetch_strike_intelligence(
            conn,
            instrument["id"],
            expiry=instrument_date,
            as_of=as_of_date,
        )

    return {"strike_intelligence": rows, "distance_from_atm": distance_from_atm}


@router.get("/history")
async def instrument_history(
    instrument_key: str = Query(...),
    from_date: str = Query(...),
    to_date: str = Query(...),
    broker_id: Optional[str] = Query(None),
) -> Dict[str, Any]:
    range_start = _parse_date(from_date)
    range_end = _parse_date(to_date)

    if not range_start or not range_end:
        raise HTTPException(status_code=400, detail="from_date and to_date must be valid ISO dates")
    if range_start > range_end:
        raise HTTPException(status_code=400, detail="from_date cannot be after to_date")

    pool = await get_db_pool()
    async with pool.acquire() as conn:
        instrument = await _fetch_instrument_by_key(conn, instrument_key)
        if not instrument:
            raise HTTPException(status_code=404, detail="Instrument key not found")

        snapshots = await _fetch_history(conn, instrument["id"], range_start, range_end)

    return {
        "instrument_key": instrument["instrument_key"],
        "history": snapshots,
    }


@router.get("/brokers")
async def list_brokers() -> Dict[str, Any]:
    pool = await get_db_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT broker_id, display_name, ingestion_mode, supported_asset_classes, last_synced_at
            FROM instrument_registry_experiments.broker_feeds
            ORDER BY broker_id
            """
        )

    brokers = [
        {
            "broker_id": row["broker_id"],
            "display_name": row["display_name"],
            "ingestion_mode": row["ingestion_mode"],
            "supported_asset_classes": row["supported_asset_classes"],
            "last_synced_at": row["last_synced_at"].isoformat() if row["last_synced_at"] else None,
        }
        for row in rows
    ]

    return {"brokers": brokers}


@router.get("/brokers/{broker_id}")
async def get_broker_details(broker_id: str = Path(...)) -> Dict[str, Any]:
    pool = await get_db_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT broker_id, display_name, registry_endpoint, ingestion_mode,
                   poll_interval_minutes, supported_asset_classes, last_synced_at, notes
            FROM instrument_registry_experiments.broker_feeds
            WHERE broker_id = $1
            """,
            broker_id,
        )

    if not row:
        raise HTTPException(status_code=404, detail="Broker configuration not found")

    return {
        "broker_id": row["broker_id"],
        "display_name": row["display_name"],
        "registry_endpoint": row["registry_endpoint"],
        "ingestion_mode": row["ingestion_mode"],
        "poll_interval_minutes": row["poll_interval_minutes"],
        "supported_asset_classes": row["supported_asset_classes"],
        "last_synced_at": row["last_synced_at"].isoformat() if row["last_synced_at"] else None,
        "notes": row["notes"],
    }


def _parse_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid ISO date: {value}")


async def _fetch_instrument_row(
    conn,
    symbol: str,
    exchange: str,
    instrument_type: Optional[str],
    asset_class: Optional[str],
    expiry: Optional[date],
    broker_id: Optional[str],
) -> Optional[Dict[str, Any]]:
    conditions: List[str] = ["symbol = $1", "exchange = $2"]
    params: List[Any] = [symbol, exchange]
    param_index = 3

    if instrument_type:
        conditions.append(f"instrument_type = ${param_index}")
        params.append(instrument_type)
        param_index += 1

    if asset_class:
        conditions.append(f"asset_class = ${param_index}")
        params.append(asset_class)
        param_index += 1

    if expiry:
        conditions.append(f"expiry = ${param_index}")
        params.append(expiry)
        param_index += 1

    if broker_id:
        conditions.append(
            f"EXISTS (SELECT 1 FROM instrument_registry_experiments.broker_instrument_tokens bt "
            f"WHERE bt.instrument_key_id = instrument_registry_experiments.instrument_keys.id "
            f"AND bt.broker_id = ${param_index})"
        )
        params.append(broker_id)
        param_index += 1

    conditions.append("is_active = true")
    where_clause = " AND ".join(conditions)

    query = (
        f"""
        SELECT id, instrument_key, symbol, exchange, segment, asset_class,
               asset_subclass, pair_base, pair_quote, quote_currency,
               settlement_currency, issuer, fund_house, is_pair, is_mutual_fund,
               instrument_type, expiry, strike, lot_size, tick_size, metadata
        FROM instrument_registry_experiments.instrument_keys
        WHERE {where_clause}
        ORDER BY updated_at DESC
        LIMIT 1
        """
    )

    return await conn.fetchrow(query, *params)


async def _fetch_instrument_by_key(conn, instrument_key: str) -> Optional[Dict[str, Any]]:
    return await conn.fetchrow(
        """
        SELECT id, instrument_key, symbol, exchange, segment, asset_class,
               asset_subclass, pair_base, pair_quote, quote_currency,
               settlement_currency, issuer, fund_house, is_pair, is_mutual_fund,
               instrument_type, expiry, strike, lot_size, tick_size, metadata
        FROM instrument_registry_experiments.instrument_keys
        WHERE instrument_key = $1
        """,
        instrument_key,
    )


async def _fetch_available_brokers(
    conn,
    instrument_key_id: int,
    as_of: Optional[date],
    broker_filter: Optional[str] = None,
) -> List[Dict[str, Any]]:
    params: List[Any] = [instrument_key_id]
    filters = ["instrument_key_id = $1"]

    if broker_filter:
        filters.append(f"broker_id = ${len(params) + 1}")
        params.append(broker_filter)

    if as_of:
        params.append(as_of)
        filters.append(
            f"valid_from <= ${len(params)} AND (valid_to >= ${len(params)} OR valid_to IS NULL)"
        )

    where_clause = " AND ".join(filters)

    rows = await conn.fetch(
        f"""
        SELECT broker_id, broker_token, valid_from, valid_to, is_active,
               source_media, additional_attributes, last_synced_at
        FROM instrument_registry_experiments.broker_instrument_tokens
        WHERE {where_clause}
        ORDER BY broker_id, valid_from DESC
        """,
        *params,
    )

    aggregated: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        token_record = {
            "token": row["broker_token"],
            "valid_from": row["valid_from"].isoformat() if row["valid_from"] else None,
            "valid_to": row["valid_to"].isoformat() if row["valid_to"] else None,
            "is_active": row["is_active"],
            "source_media": row["source_media"],
            "attributes": row["additional_attributes"],
            "last_synced_at": row["last_synced_at"].isoformat() if row["last_synced_at"] else None,
        }
        aggregated.setdefault(row["broker_id"], []).append(token_record)

    return [
        {"broker_id": broker_id, "tokens": tokens}
        for broker_id, tokens in aggregated.items()
    ]


async def _fetch_strike_intelligence(
    conn,
    instrument_key_id: int,
    expiry: Optional[date],
    as_of: Optional[date],
) -> List[Dict[str, Any]]:
    params: List[Any] = [instrument_key_id]
    filters = ["instrument_key_id = $1"]

    if expiry:
        params.append(expiry)
        filters.append(f"expiry_date = ${len(params)}")

    if as_of:
        params.append(as_of)
        filters.append(f"created_at::date <= ${len(params)}")

    where_clause = " AND ".join(filters)
    rows = await conn.fetch(
        f"""
        SELECT distance_tier, strike_interval, atm_reference, density,
               expiry_date, source_feed, created_at
        FROM instrument_registry_experiments.strike_intelligence
        WHERE {where_clause}
        ORDER BY expiry_date DESC NULLS LAST, distance_tier
        """,
        *params,
    )

    return [
        {
            "distance_tier": row["distance_tier"],
            "strike_interval": float(row["strike_interval"]),
            "atm_reference": float(row["atm_reference"]) if row["atm_reference"] else None,
            "density": row["density"],
            "expiry_date": row["expiry_date"].isoformat() if row["expiry_date"] else None,
            "source_feed": row["source_feed"],
            "created_at": row["created_at"].isoformat() if row["created_at"] else None,
        }
        for row in rows
    ]


async def _fetch_history(
    conn,
    instrument_key_id: int,
    start_date: date,
    end_date: date,
) -> List[Dict[str, Any]]:
    rows = await conn.fetch(
        """
        SELECT snapshot_date, expiry, strike, lot_size, tick_size, metadata, exists
        FROM instrument_registry_experiments.instrument_history_snapshots
        WHERE instrument_key_id = $1
          AND snapshot_date BETWEEN $2 AND $3
        ORDER BY snapshot_date
        """,
        instrument_key_id,
        start_date,
        end_date,
    )
    return [
        {
            "date": row["snapshot_date"].isoformat(),
            "expiry": row["expiry"].isoformat() if row["expiry"] else None,
            "strike": float(row["strike"]) if row["strike"] else None,
            "lot_size": float(row["lot_size"]) if row["lot_size"] else None,
            "tick_size": float(row["tick_size"]) if row["tick_size"] else None,
            "metadata": row["metadata"],
            "exists": row["exists"],
        }
        for row in rows
    ]
