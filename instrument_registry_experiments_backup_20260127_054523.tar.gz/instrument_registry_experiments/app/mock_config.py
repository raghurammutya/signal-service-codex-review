"""Mock configuration client used during experiments."""

from __future__ import annotations

import os
from typing import Dict


class MockConfigServiceClient:
    """Stand-in config client that serves configured defaults."""

    DEFAULT_CONFIGS: Dict[str, str] = {
        "INSTRUMENT_REGISTRY_EXPERIMENTS_DATABASE_URL": "postgresql://postgres:postgres@localhost:5432/instrument_registry_experiments",
        "TOKEN_MANAGER_INTERNAL_URL": "http://localhost:8088/api/v1",
        "KITE_BROKER_ID": "kite",
        "KITE_SEGMENTS": "NFO,BFO,NSE,BSE,CDS,MCX",
        "STRIKE_DISTANCE_DEFAULTS": "{}",
        "INSTRUMENT_REGISTRY_EXPERIMENTS_API_URL": "http://localhost:8000/api/v1/internal/instrument-registry-experiments",
        "INSTRUMENT_REGISTRY_PROXY_DEFAULT_BROKER": "kite",
        "INSTRUMENT_REGISTRY_PROXY_REFRESH_INTERVAL_SECONDS": "300",
        "INSTRUMENT_REGISTRY_PROXY_WATCHED_INSTRUMENTS": "[]",
    }

    DEFAULT_SECRETS: Dict[str, str] = {
        "TOKEN_MANAGER_INTERNAL_API_KEY": "mock-token-manager",
        "KITE_API_KEY": "mock-kite-key",
        "INSTRUMENT_REGISTRY_EXPERIMENTS_API_KEY": "mock-internal-key",
    }

    def __init__(self, service_name: str, environment: str) -> None:
        self.service_name = service_name
        self.environment = environment

    def health_check(self) -> bool:
        return True

    def get_config(self, key: str, required: bool = True) -> str | None:
        env_key = f"MOCK_CONFIG_{key}"
        value = os.getenv(env_key)
        if value is None:
            value = self.DEFAULT_CONFIGS.get(key)
        if not value and required:
            raise RuntimeError(f"Mock config missing required key: {key}")
        return value

    def get_secret(self, key: str, required: bool = True) -> str | None:
        env_key = f"MOCK_SECRET_{key}"
        value = os.getenv(env_key)
        if value is None:
            value = self.DEFAULT_SECRETS.get(key)
        if not value and required:
            raise RuntimeError(f"Mock secret missing required key: {key}")
        return value
