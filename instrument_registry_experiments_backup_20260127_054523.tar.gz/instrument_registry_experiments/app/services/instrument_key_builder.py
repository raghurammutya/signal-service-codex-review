"""
Instrument Key Builder

Builds canonical instrument keys that describe exchanges, asset classes,
and security metadata so that every broker and service refers to the same
instrument.
"""

from datetime import date
from typing import Optional


def build_instrument_key(
    exchange: str,
    symbol: str,
    segment: Optional[str] = None,
    instrument_type: Optional[str] = None,
    expiry: Optional[date] = None,
    strike: Optional[float] = None,
    asset_class: Optional[str] = None,
    pair_base: Optional[str] = None,
    pair_quote: Optional[str] = None,
    is_pair: bool = False,
    is_mutual_fund: bool = False,
    fund_house: Optional[str] = None,
) -> str:
    exchange = (exchange or "").upper()
    segment_lower = (segment or "").lower()

    is_index = segment_lower in ("indices", "index")
    asset_class_upper = (asset_class or "").upper()

    if (pair_base and pair_quote) or is_pair:
        base = pair_base or ""
        quote = pair_quote or ""
        return f"{asset_class_upper or 'PAIR'}@{base}-{quote}@pair"

    if is_mutual_fund:
        fund_tag = (fund_house or "mf").replace(" ", "_").lower()
        return f"{asset_class_upper or 'MF'}@{symbol}@mutualfund@{fund_tag}"

    if expiry and instrument_type in ("CE", "PE"):
        option_type = "call" if instrument_type == "CE" else "put"
        strike_int = int(strike) if strike else 0
        expiry_str = expiry.isoformat() if hasattr(expiry, "isoformat") else str(expiry)
        return f"{exchange}@{symbol}@options@{expiry_str}@{option_type}@{strike_int}"

    if expiry and instrument_type in ("FUT", "FUTIDX", "FUTSTK"):
        expiry_str = expiry.isoformat() if hasattr(expiry, "isoformat") else str(expiry)
        return f"{exchange}@{symbol}@futures@{expiry_str}"

    if is_index:
        return f"{exchange}@{symbol}@index_spot"

    return f"{exchange}@{symbol}@equity_spot"


def build_metadata_from_instrument(record: dict) -> dict:
    return {
        "kite_instrument_token": record.get("instrument_token"),
        "segment": record.get("segment"),
        "market_segment": record.get("segment"),
        "source": record.get("source") or "kite",
        "asset_subclass": record.get("asset_subclass"),
        "pair_base": record.get("pair_base"),
        "pair_quote": record.get("pair_quote"),
        "quote_currency": record.get("quote_currency"),
        "settlement_currency": record.get("settlement_currency"),
        "issuer": record.get("issuer"),
        "fund_house": record.get("fund_house"),
        "is_pair": record.get("is_pair", False),
        "is_mutual_fund": record.get("is_mutual_fund", False),
    }
