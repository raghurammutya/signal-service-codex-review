"""Kite/Zerodha instrument ingestion adapter for the experimental registry."""

from __future__ import annotations

import asyncio
import logging
from datetime import date, datetime
from typing import Dict, Optional

import asyncpg
import httpx

from kiteconnect import KiteConnect

from ..config import ExperimentConfig
from ..db import get_db_pool
from .instrument_key_builder import build_instrument_key, build_metadata_from_instrument

logger = logging.getLogger(__name__)


def _parse_expiry(value: Optional[date | str | datetime]) -> Optional[date]:
    if value is None:
        return None
    if isinstance(value, str):
        try:
            return date.fromisoformat(value)
        except ValueError:
            return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return None


class KiteInstrumentIngestor:
    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config
        self.broker_id = config.kite_broker_id

    async def refresh(self) -> None:
        token_request = await self._fetch_token()
        if not token_request:
            logger.error("Unable to retrieve Kite access token")
            return

        kite = KiteConnect(api_key=self.config.kite_api_key)
        kite.set_access_token(token_request["access_token"])
        loop = asyncio.get_event_loop()
        segments = self.config.segments
        pool = await get_db_pool()

        total = 0
        for segment in segments:
            try:
                instruments = await loop.run_in_executor(None, kite.instruments, segment)
            except Exception as exc:
                logger.exception("Failed to fetch instruments for %s: %s", segment, exc)
                continue

            if not instruments:
                continue

            async with pool.acquire() as conn:
                for inst in instruments:
                    await self._process_instrument(segment, inst, conn)

            total += len(instruments)
            logger.info("Indexed %s instruments for segment %s", len(instruments), segment)

        logger.info("Kite ingestion completed (%d instruments).", total)

    async def _fetch_token(self) -> Optional[Dict[str, str]]:
        headers = {"X-Internal-API-Key": self.config.token_manager_api_key}
        url = f"{self.config.token_manager_url}/api/v1/tokens/primary"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=headers)
            if resp.status_code != 200:
                logger.error("Token manager responded %s", resp.status_code)
                return None
            return resp.json()

    async def _process_instrument(self, segment: str, instrument: Dict[str, any], conn: asyncpg.Connection) -> None:
        symbol = instrument.get("tradingsymbol") or instrument.get("symbol")
        if not symbol:
            return

        expiry = _parse_expiry(instrument.get("expiry"))
        instrument_type = instrument.get("instrument_type")
        strike = instrument.get("strike") or 0.0
        lot_size = instrument.get("lot_size")
        tick_size = instrument.get("tick_size")
        exchange = instrument.get("exchange") or ""
        asset_class = self._classify_asset(instrument_type, segment)

        instrument_key = build_instrument_key(
            exchange=exchange,
            symbol=symbol,
            segment=segment,
            instrument_type=instrument_type,
            expiry=expiry,
            strike=strike,
        )

        instrument_id = await self._upsert_instrument_key(
            conn,
            symbol,
            exchange,
            segment,
            instrument_key,
            asset_class,
            instrument_type,
            expiry,
            strike,
            lot_size,
            tick_size,
            instrument.get("name"),
            instrument,
        )

        await self._upsert_broker_token(conn, instrument_id, instrument, expiry)
        await self._record_history(conn, instrument_id, expiry, strike, lot_size, tick_size, instrument)

    async def _upsert_instrument_key(
        self,
        conn: asyncpg.Connection,
        symbol: str,
        exchange: str,
        segment: str,
        instrument_key: str,
        asset_class: str,
        instrument_type: Optional[str],
        expiry: Optional[date],
        strike: Optional[float],
        lot_size: Optional[float],
        tick_size: Optional[float],
        name: Optional[str],
        source_record: Dict[str, any],
    ) -> int:
        metadata = build_metadata_from_instrument(source_record)
        metadata["source_catalog"] = "kite"
        query = """
            INSERT INTO instrument_registry_experiments.instrument_keys (
                symbol, exchange, segment, asset_class, asset_subclass,
                pair_base, pair_quote, quote_currency, settlement_currency,
                issuer, fund_house, is_pair, is_mutual_fund,
                instrument_type, name, currency, expiry, strike,
                lot_size, tick_size, instrument_key, metadata, source_catalog, updated_at
            ) VALUES (
                $1,$2,$3,$4,$5,
                $6,$7,$8,$9,
                $10,$11,$12,$13,
                $14,$15,$16,$17,$18,
                $19,$20,$21,$22,$23,now()
            )
            ON CONFLICT (instrument_key) DO UPDATE SET
                symbol = EXCLUDED.symbol,
                exchange = EXCLUDED.exchange,
                segment = EXCLUDED.segment,
                asset_class = EXCLUDED.asset_class,
                asset_subclass = EXCLUDED.asset_subclass,
                pair_base = EXCLUDED.pair_base,
                pair_quote = EXCLUDED.pair_quote,
                quote_currency = EXCLUDED.quote_currency,
                settlement_currency = EXCLUDED.settlement_currency,
                issuer = EXCLUDED.issuer,
                fund_house = EXCLUDED.fund_house,
                is_pair = EXCLUDED.is_pair,
                is_mutual_fund = EXCLUDED.is_mutual_fund,
                instrument_type = EXCLUDED.instrument_type,
                name = EXCLUDED.name,
                lot_size = COALESCE(EXCLUDED.lot_size, instrument_registry_experiments.instrument_keys.lot_size),
                tick_size = COALESCE(EXCLUDED.tick_size, instrument_registry_experiments.instrument_keys.tick_size),
                metadata = EXCLUDED.metadata,
                source_catalog = EXCLUDED.source_catalog,
                updated_at = now()
            RETURNING id
        """
        currency = source_record.get("currency") or "INR"
        asset_subclass = source_record.get("asset_subclass")
        pair_base = source_record.get("pair_base")
        pair_quote = source_record.get("pair_quote")
        quote_currency = source_record.get("quote_currency") or currency
        settlement_currency = source_record.get("settlement_currency")
        issuer = source_record.get("issuer")
        fund_house = source_record.get("fund_house")
        is_pair = bool(
            source_record.get("is_pair")
            or (pair_base and pair_quote)
        )
        is_mutual_fund = bool(source_record.get("is_mutual_fund"))
        instrument_id = await conn.fetchval(
            query,
            symbol,
            exchange,
            segment,
            asset_class,
            asset_subclass,
            pair_base,
            pair_quote,
            quote_currency,
            settlement_currency,
            issuer,
            fund_house,
            is_pair,
            is_mutual_fund,
            instrument_type or "OTHER",
            name,
            currency,
            expiry,
            strike,
            lot_size,
            tick_size,
            instrument_key,
            metadata,
            "kite",
        )
        return instrument_id

    async def _upsert_broker_token(
        self,
        conn: asyncpg.Connection,
        instrument_key_id: int,
        instrument: Dict[str, any],
        expiry: Optional[date],
    ) -> None:
        token = instrument.get("instrument_token") or str(instrument.get("token"))
        if not token:
            return

        valid_from = date.today()
        valid_to = expiry
        additional_attributes = {
            "tradingsymbol": instrument.get("tradingsymbol"),
            "segment": instrument.get("segment"),
            "lot_size": instrument.get("lot_size"),
            "tick_size": instrument.get("tick_size"),
        }

        await conn.execute(
            """
            INSERT INTO instrument_registry_experiments.broker_instrument_tokens (
                broker_id, instrument_key_id, broker_token, valid_from, valid_to,
                is_active, source_media, additional_attributes, last_synced_at
            ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,now())
            ON CONFLICT (broker_id, instrument_key_id, valid_from) DO UPDATE SET
                broker_token = EXCLUDED.broker_token,
                valid_to = EXCLUDED.valid_to,
                is_active = TRUE,
                source_media = EXCLUDED.source_media,
                additional_attributes = EXCLUDED.additional_attributes,
                last_synced_at = now()
            """,
            self.broker_id,
            instrument_key_id,
            token,
            valid_from,
            valid_to,
            True,
            "api",
            additional_attributes,
        )

    async def _record_history(
        self,
        conn: asyncpg.Connection,
        instrument_key_id: int,
        expiry: Optional[date],
        strike: Optional[float],
        lot_size: Optional[float],
        tick_size: Optional[float],
        instrument: Dict[str, any],
    ) -> None:
        await conn.execute(
            """
            INSERT INTO instrument_registry_experiments.instrument_history_snapshots (
                snapshot_date, instrument_key_id, expiry, strike, lot_size, tick_size, metadata, exists
            ) VALUES (current_date,$1,$2,$3,$4,$5,$6,TRUE)
            ON CONFLICT (snapshot_date, instrument_key_id) DO UPDATE SET
                expiry = EXCLUDED.expiry,
                strike = EXCLUDED.strike,
                lot_size = EXCLUDED.lot_size,
                tick_size = EXCLUDED.tick_size,
                metadata = EXCLUDED.metadata,
                exists = TRUE
            """,
            instrument_key_id,
            expiry,
            strike,
            lot_size,
            tick_size,
            {"instrument_token": instrument.get("instrument_token")},
        )

    @staticmethod
    def _classify_asset(instrument_type: Optional[str], segment: str) -> str:
        if instrument_type in ("CE", "PE"):
            return "option"
        if instrument_type in ("FUT", "FUTIDX", "FUTSTK"):
            return "future"
        if segment in ("CDS", "MCX"):
            return "commodity"
        if instrument_type == "EQ":
            return "equity"
        return "other"
