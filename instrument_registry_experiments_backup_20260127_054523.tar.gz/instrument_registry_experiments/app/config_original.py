"""Configuration helpers for the instrument registry experiments service."""

from __future__ import annotations

import logging
import os
import sys
from typing import List

logger = logging.getLogger(__name__)

SERVICE_NAME = "instrument_registry_experiments"
DEFAULT_ENVIRONMENT = os.getenv("ENVIRONMENT", "prod")
_USE_MOCK_CONFIG = os.getenv(
    "INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG", "false"
).lower() in {"1", "true", "yes", "on"}

# Ensure repo root is on sys.path so `common` modules can be imported
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from common.config_service.client import ConfigServiceClient  # noqa: E402

SERVICE_NAME = "instrument_registry_experiments"
DEFAULT_ENVIRONMENT = os.getenv("ENVIRONMENT", "prod")

_config_client: ConfigServiceClient | None = None
_config_client_error: str | None = None


def _get_config_client() -> ConfigServiceClient:
    global _config_client, _config_client_error

    if _config_client:
        return _config_client

    if _USE_MOCK_CONFIG:
        from .mock_config import MockConfigServiceClient  # noqa: WPS433

        client = MockConfigServiceClient(service_name=SERVICE_NAME, environment=DEFAULT_ENVIRONMENT)
        _config_client = client
        return _config_client

    try:
        client = ConfigServiceClient(service_name=SERVICE_NAME, environment=DEFAULT_ENVIRONMENT)
        if not client.health_check():
            _config_client_error = "Config service health check failed"
            logger.critical("Config service is unavailable - experiment service cannot proceed")
            raise RuntimeError(_config_client_error)

        _config_client = client
        return _config_client
    except Exception as exc:
        _config_client_error = str(exc)
        logger.critical(
            "Failed to initialize ConfigServiceClient: %s", _config_client_error
        )
        raise


def _get_config_value(key: str, required: bool = True) -> str:
    client = _get_config_client()
    value = client.get_config(key, required=required)
    if required and not value:
        logger.critical("Required config missing: %s", key)
        raise RuntimeError(f"Missing config: {key}")
    return value


def _get_secret_value(key: str, required: bool = True) -> str:
    client = _get_config_client()
    value = client.get_secret(key, required=required)
    if required and not value:
        logger.critical("Required secret missing: %s", key)
        raise RuntimeError(f"Missing secret: {key}")
    return value


class ExperimentConfig:
    """Holds the minimal configuration required by the ingestion adapter."""

    def __init__(self) -> None:
        self.database_url = _get_config_value("INSTRUMENT_REGISTRY_EXPERIMENTS_DATABASE_URL")
        self.token_manager_url = _get_config_value("TOKEN_MANAGER_INTERNAL_URL")
        self.token_manager_api_key = _get_secret_value("TOKEN_MANAGER_INTERNAL_API_KEY")
        self.kite_api_key = _get_secret_value("KITE_API_KEY")
        self.kite_broker_id = _get_config_value("KITE_BROKER_ID")
        self.kite_segments = _get_config_value("KITE_SEGMENTS", required=False) or "NFO,BFO,NSE,BSE,CDS,MCX"
        self.strike_distance_defaults = _get_config_value("STRIKE_DISTANCE_DEFAULTS", required=False)

    @property
    def segments(self) -> List[str]:
        return [segment.strip() for segment in self.kite_segments.split(",") if segment.strip()]
