# Calendar Service Migration Guide for Instrument Registry

## Overview

This guide details the migration from time-based scheduling to calendar-aware operations in the instrument registry experiments service.

## Changes Made

### 1. New Calendar-Aware Components

#### Proxy Service (`proxy/calendar_aware_run_proxy.py`)
- Replaces `proxy/run_proxy.py`
- Integrates with calendar service for market-aware refresh scheduling
- Dynamically adjusts refresh intervals based on market state:
  - **Market Open**: 1 minute intervals
  - **Pre/Post Market**: 3-5 minute intervals  
  - **Market Closed**: 30 minute intervals
  - **Holidays/Weekends**: 1 hour intervals

#### Configuration (`app/proxy/calendar_config.py`)
- Extends `ProxyConfig` with calendar settings
- Supports multiple exchanges (NSE, BSE, etc.)
- Configurable refresh windows and market-aware behaviors
- Graceful fallback when calendar service unavailable

#### Health Check (`proxy/calendar_aware_health.py`)
- Replaces `proxy/health.py`
- Market-aware staleness detection
- Different thresholds for different market states
- Shows current market states in health response

### 2. Removed Components

The following hardcoded time-based logic has been removed:
- Fixed 5-minute refresh intervals
- Static 10-minute staleness threshold
- Time-based polling loops without market awareness

### 3. Configuration Changes

#### Environment Variables

```bash
# Calendar Service Connection
CALENDAR_SERVICE_URL=http://calendar-service:8080
CALENDAR_SERVICE_API_KEY=<your-api-key>

# Market-Aware Behavior
INSTRUMENT_REGISTRY_REFRESH_DURING_MARKET=true  # or false to skip market hours
INSTRUMENT_REGISTRY_SKIP_HOLIDAYS=true
INSTRUMENT_REGISTRY_SKIP_WEEKENDS=true

# Monitored Exchanges
INSTRUMENT_REGISTRY_MONITORED_EXCHANGES='["NSE","BSE"]'

# Custom Intervals (optional)
INSTRUMENT_REGISTRY_MARKET_OPEN_INTERVAL=60      # seconds
INSTRUMENT_REGISTRY_PRE_MARKET_INTERVAL=180      # seconds
INSTRUMENT_REGISTRY_POST_MARKET_INTERVAL=300     # seconds
INSTRUMENT_REGISTRY_CLOSED_MARKET_INTERVAL=1800  # seconds
INSTRUMENT_REGISTRY_HOLIDAY_INTERVAL=3600        # seconds

# Legacy (remove after migration)
# INSTRUMENT_REGISTRY_PROXY_REFRESH_INTERVAL_SECONDS=300
```

## Migration Steps

### Phase 1: Parallel Running
1. Deploy new calendar-aware components alongside existing ones
2. Monitor both services to ensure calendar integration works correctly
3. Compare refresh patterns and validate cache freshness

### Phase 2: Gradual Cutover
1. Update service configurations to use calendar-aware endpoints
2. Switch health checks to calendar-aware version
3. Monitor for any issues with market-aware behavior

### Phase 3: Cleanup
1. Remove old `run_proxy.py` and `health.py` files
2. Remove legacy configuration variables
3. Update documentation and runbooks

## Rollback Plan

If issues arise, rollback is straightforward:
1. Switch back to original `run_proxy.py`
2. Restore original health endpoint
3. Calendar-aware components will gracefully fallback to time-based behavior

## Benefits

1. **Reduced Infrastructure Load**
   - No unnecessary refreshes during non-trading hours
   - Significant reduction in database queries on weekends/holidays

2. **Better Cache Freshness**
   - More frequent updates during active trading
   - Relaxed staleness during non-trading periods

3. **Cost Savings**
   - Reduced compute during off-hours
   - Lower network and database costs

4. **Operational Excellence**
   - Automatic handling of market holidays
   - No manual intervention for special market days
   - Consistent behavior across all market events

## Monitoring

### New Metrics
```
# Calendar service integration
instrument_registry_calendar_requests_total
instrument_registry_calendar_errors_total
instrument_registry_market_state{exchange="NSE",state="OPEN"}

# Refresh patterns
instrument_registry_refresh_interval_seconds{market_state="OPEN"}
instrument_registry_cache_staleness_minutes{acceptable="true"}
```

### Alerts
- Calendar service unavailable for > 5 minutes
- Cache staleness during market hours
- Failed market state checks

## Verification

To verify the migration:

```bash
# Check health with market states
curl http://localhost:8000/health

# Sample response:
{
  "status": "healthy",
  "last_refreshed": "2024-01-25T10:30:00Z",
  "token_count": 5432,
  "stale": false,
  "market_states": {
    "NSE": "OPEN",
    "BSE": "OPEN"
  },
  "staleness_threshold_minutes": 5,
  "reason": null
}

# During non-trading hours:
{
  "status": "healthy",
  "last_refreshed": "2024-01-25T22:30:00Z",
  "token_count": 5432,
  "stale": true,
  "market_states": {
    "NSE": "CLOSED",
    "BSE": "CLOSED"
  },
  "staleness_threshold_minutes": 30,
  "reason": "Cache staleness acceptable during non-trading period"
}
```

## Next Steps

1. **Database Schema Updates**
   - Remove `poll_interval_minutes` from `broker_feeds` table
   - Add calendar-aware scheduling metadata

2. **Additional Integrations**
   - Batch processing aligned with market events
   - Maintenance window coordination
   - Capacity scaling based on market activity

3. **Enhanced Features**
   - Pre-fetch before market open
   - Expiry-aware refresh patterns
   - Multi-timezone support for international markets