# Instrument Registry Experiments Service

This scaffold hosts the experimental service for exploring multi-broker, multi-asset instrument handling without touching the main `ticker_service` schema.

## Contents
- `migrations/0001_create_schema.sql`: Creates the `instrument_registry_experiments` schema with canonical instrument keys, broker tokens, strike intelligence, and historical snapshots.
- `docs/API_SPEC.md`: Detailed internal API contract for the service.
- `app/api/instrument_registry.py`: FastAPI router skeleton exposing the experimental endpoints.

## Next Steps
1. Implement ingestion adapters that populate `broker_feeds`, `instrument_keys`, and `broker_instrument_tokens` for each broker (Kite/Zerodha, other APIs, crypto feeds, etc.).
2. Fill in the routers with database access and config-driven parameters before merging back into `ticker_service`.
3. Hook this service into instrumentation/monitoring so violation alerts can be generated during experiments.
