"""Entry point to refresh the Kite/Zerodha instrument registry snapshot."""

from __future__ import annotations

import asyncio
import logging

from app.config import ExperimentConfig
from app.db import close_db_pool, get_db_pool
from app.services.kite_ingest import KiteInstrumentIngestor

logging.basicConfig(level=logging.INFO)


async def main() -> None:
    config = ExperimentConfig()
    pool = await get_db_pool()
    try:
        ingestor = KiteInstrumentIngestor(config)
        await ingestor.refresh()
    finally:
        await close_db_pool()


if __name__ == "__main__":
    asyncio.run(main())
