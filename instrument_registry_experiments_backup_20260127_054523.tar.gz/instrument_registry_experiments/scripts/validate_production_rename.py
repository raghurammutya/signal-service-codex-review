#!/usr/bin/env python3
"""
Validation script to ensure production rename was successful
Checks all critical functionality and configurations
"""

import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import httpx
import asyncpg
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ProductionValidator:
    def __init__(self):
        self.base_url = os.getenv("INSTRUMENT_REGISTRY_API_URL", "http://localhost:8084")
        self.db_url = os.getenv("DATABASE_URL", "postgresql://user:pass@localhost/instrument_registry")
        self.results = {
            "passed": [],
            "failed": [],
            "warnings": []
        }
    
    async def check_api_endpoints(self) -> bool:
        """Validate all API endpoints are accessible with new paths"""
        endpoints = [
            ("/health", "GET", 200),
            ("/ready", "GET", 200),
            ("/api/v1/internal/instrument-registry/brokers", "GET", 200),
            ("/api/v1/internal/instrument-registry/resolve?symbol=RELIANCE", "GET", 200),
        ]
        
        async with httpx.AsyncClient() as client:
            for path, method, expected_status in endpoints:
                try:
                    url = f"{self.base_url}{path}"
                    response = await client.request(method, url, timeout=5.0)
                    
                    if response.status_code == expected_status:
                        self.results["passed"].append(f"API endpoint {method} {path}")
                    else:
                        self.results["failed"].append(
                            f"API endpoint {method} {path} returned {response.status_code}, expected {expected_status}"
                        )
                except Exception as e:
                    self.results["failed"].append(f"API endpoint {method} {path}: {str(e)}")
        
        # Check that old paths are not accessible
        old_path = "/api/v1/internal/instrument-registry-experiments/brokers"
        try:
            response = await client.get(f"{self.base_url}{old_path}")
            if response.status_code != 404:
                self.results["failed"].append(f"Old API path still accessible: {old_path}")
        except:
            self.results["passed"].append("Old API paths properly removed")
        
        return len([r for r in self.results["failed"] if "API endpoint" in r]) == 0
    
    async def check_database_schema(self) -> bool:
        """Validate new database schema exists and is accessible"""
        try:
            conn = await asyncpg.connect(self.db_url)
            
            # Check new schema exists
            schema_exists = await conn.fetchval("""
                SELECT EXISTS (
                    SELECT 1 FROM information_schema.schemata 
                    WHERE schema_name = 'instrument_registry'
                )
            """)
            
            if schema_exists:
                self.results["passed"].append("Database schema 'instrument_registry' exists")
            else:
                self.results["failed"].append("Database schema 'instrument_registry' not found")
                return False
            
            # Check tables exist
            tables = ['broker_feeds', 'instrument_keys', 'broker_instrument_tokens', 
                     'instrument_history_snapshots', 'strike_intelligence']
            
            for table in tables:
                table_exists = await conn.fetchval(f"""
                    SELECT EXISTS (
                        SELECT 1 FROM information_schema.tables 
                        WHERE table_schema = 'instrument_registry' 
                        AND table_name = '{table}'
                    )
                """)
                
                if table_exists:
                    self.results["passed"].append(f"Table instrument_registry.{table} exists")
                else:
                    self.results["failed"].append(f"Table instrument_registry.{table} not found")
            
            # Check data migrated
            for table in tables:
                old_count = await conn.fetchval(
                    f"SELECT COUNT(*) FROM instrument_registry_experiments.{table}"
                )
                new_count = await conn.fetchval(
                    f"SELECT COUNT(*) FROM instrument_registry.{table}"
                )
                
                if old_count == new_count:
                    self.results["passed"].append(
                        f"Data migrated successfully for {table} ({new_count} rows)"
                    )
                else:
                    self.results["failed"].append(
                        f"Data mismatch for {table}: old={old_count}, new={new_count}"
                    )
            
            await conn.close()
            return True
            
        except Exception as e:
            self.results["failed"].append(f"Database validation error: {str(e)}")
            return False
    
    async def check_configuration(self) -> bool:
        """Validate configuration is properly updated"""
        checks_passed = True
        
        # Check environment variables
        required_vars = [
            "INSTRUMENT_REGISTRY_DATABASE_URL",
            "INSTRUMENT_REGISTRY_API_URL",
            "CALENDAR_SERVICE_URL",
            "MESSAGE_SERVICE_URL",
            "EVENT_STORE_URL"
        ]
        
        for var in required_vars:
            if os.getenv(var):
                self.results["passed"].append(f"Environment variable {var} is set")
            else:
                self.results["warnings"].append(f"Environment variable {var} not set")
        
        # Check mock config is removed
        if "INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG" in os.environ:
            self.results["failed"].append("Mock config flag still present in environment")
            checks_passed = False
        else:
            self.results["passed"].append("Mock config flag removed")
        
        return checks_passed
    
    async def check_code_references(self) -> bool:
        """Check that code no longer contains experiment references"""
        base_path = Path("/home/stocksadmin/instrument_registry")
        if not base_path.exists():
            self.results["failed"].append(f"Directory {base_path} does not exist")
            return False
        
        experiment_references = []
        
        # Search for remaining experiment references
        for file_path in base_path.rglob("*.py"):
            try:
                content = file_path.read_text()
                if "instrument_registry_experiments" in content:
                    lines = [i+1 for i, line in enumerate(content.splitlines()) 
                            if "instrument_registry_experiments" in line]
                    experiment_references.append((file_path, lines))
            except:
                pass
        
        if experiment_references:
            for file_path, lines in experiment_references:
                self.results["failed"].append(
                    f"Found experiment references in {file_path} at lines: {lines}"
                )
            return False
        else:
            self.results["passed"].append("No experiment references found in code")
            return True
    
    async def check_ingestion_endpoint(self) -> bool:
        """Validate ingestion endpoint is implemented"""
        async with httpx.AsyncClient() as client:
            url = f"{self.base_url}/api/v1/internal/instrument-registry/brokers/kite/ingest"
            
            # Try to call ingestion endpoint
            try:
                response = await client.post(
                    url,
                    json={"mode": "INCREMENTAL", "filters": {}},
                    headers={"X-Internal-API-Key": os.getenv("INTERNAL_API_KEY", "test")},
                    timeout=5.0
                )
                
                # Should return 202 (queued) or 401 (auth) but not 501 (not implemented)
                if response.status_code == 501:
                    self.results["failed"].append("Ingestion endpoint still returns 501 (not implemented)")
                    return False
                elif response.status_code in [202, 401, 404]:
                    self.results["passed"].append(f"Ingestion endpoint implemented (status: {response.status_code})")
                    return True
                else:
                    self.results["warnings"].append(
                        f"Ingestion endpoint returned unexpected status: {response.status_code}"
                    )
                    return True
                    
            except Exception as e:
                self.results["failed"].append(f"Ingestion endpoint error: {str(e)}")
                return False
    
    async def run_all_checks(self) -> bool:
        """Run all validation checks"""
        logger.info("Starting production validation...")
        
        checks = [
            ("API Endpoints", self.check_api_endpoints),
            ("Database Schema", self.check_database_schema),
            ("Configuration", self.check_configuration),
            ("Code References", self.check_code_references),
            ("Ingestion Endpoint", self.check_ingestion_endpoint)
        ]
        
        all_passed = True
        
        for check_name, check_func in checks:
            logger.info(f"Running {check_name} check...")
            try:
                passed = await check_func()
                if not passed:
                    all_passed = False
            except Exception as e:
                self.results["failed"].append(f"{check_name} check failed with error: {str(e)}")
                all_passed = False
        
        return all_passed
    
    def print_results(self):
        """Print validation results"""
        print("\n" + "="*80)
        print("PRODUCTION VALIDATION RESULTS")
        print("="*80)
        
        if self.results["passed"]:
            print(f"\n✅ PASSED ({len(self.results['passed'])} checks)")
            for result in self.results["passed"]:
                print(f"   ✓ {result}")
        
        if self.results["warnings"]:
            print(f"\n⚠️  WARNINGS ({len(self.results['warnings'])} issues)")
            for result in self.results["warnings"]:
                print(f"   ⚠ {result}")
        
        if self.results["failed"]:
            print(f"\n❌ FAILED ({len(self.results['failed'])} checks)")
            for result in self.results["failed"]:
                print(f"   ✗ {result}")
        
        print("\n" + "="*80)
        
        if not self.results["failed"]:
            print("✅ ALL CRITICAL CHECKS PASSED - Ready for production!")
        else:
            print("❌ VALIDATION FAILED - Please fix the issues above")
        
        print("="*80 + "\n")
        
        # Save results to file
        results_file = Path("validation_results.json")
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        print(f"Results saved to {results_file}")


async def main():
    validator = ProductionValidator()
    success = await validator.run_all_checks()
    validator.print_results()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())