#!/usr/bin/env python3
"""
Script to rename instrument_registry_experiments to instrument_registry
Handles all code, configuration, and documentation updates
"""

import os
import re
import shutil
import logging
from pathlib import Path
from typing import List, Tuple

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ProductionRenamer:
    def __init__(self, base_path: str = "/home/stocksadmin"):
        self.base_path = Path(base_path)
        self.old_name = "instrument_registry_experiments"
        self.new_name = "instrument_registry"
        self.old_dir = self.base_path / self.old_name
        self.new_dir = self.base_path / self.new_name
        
        # Patterns to replace
        self.replacements = [
            # Package imports
            (r'from instrument_registry_experiments', 'from instrument_registry'),
            (r'import instrument_registry_experiments', 'import instrument_registry'),
            
            # API paths
            (r'/instrument-registry-experiments', '/instrument-registry'),
            (r'instrument-registry-experiments/', 'instrument-registry/'),
            
            # Environment variables
            (r'INSTRUMENT_REGISTRY_EXPERIMENTS_', 'INSTRUMENT_REGISTRY_'),
            
            # Service names
            (r'"instrument_registry_experiments"', '"instrument_registry"'),
            (r"'instrument_registry_experiments'", "'instrument_registry'"),
            
            # API titles
            (r'Instrument Registry Experiments API', 'Instrument Registry API'),
            (r'instrument registry experiments', 'instrument registry'),
            
            # Schema names
            (r'instrument_registry_experiments\.', 'instrument_registry.'),
            
            # Docker/K8s names
            (r'instrument-registry-experiments', 'instrument-registry'),
            
            # Remove mock config flag references
            (r'INSTRUMENT_REGISTRY_EXPERIMENTS_USE_MOCK_CONFIG.*\n', ''),
            (r'if.*USE_MOCK_CONFIG.*:\n.*\n.*\n', ''),
        ]
        
        # Files to process
        self.file_extensions = ['.py', '.sql', '.md', '.yaml', '.yml', '.json', '.sh', '.env', '.txt']
        
    def backup_directory(self):
        """Create a backup of the original directory"""
        backup_path = self.base_path / f"{self.old_name}_backup_{int(time.time())}"
        logger.info(f"Creating backup at {backup_path}")
        shutil.copytree(self.old_dir, backup_path)
        return backup_path
    
    def rename_in_file(self, file_path: Path) -> int:
        """Apply all replacements to a single file"""
        try:
            content = file_path.read_text(encoding='utf-8')
            original_content = content
            changes = 0
            
            for pattern, replacement in self.replacements:
                new_content, count = re.subn(pattern, replacement, content, flags=re.MULTILINE)
                if count > 0:
                    content = new_content
                    changes += count
            
            if changes > 0:
                file_path.write_text(content, encoding='utf-8')
                logger.info(f"Updated {file_path} with {changes} changes")
            
            return changes
        except Exception as e:
            logger.error(f"Error processing {file_path}: {e}")
            return 0
    
    def process_directory(self, directory: Path) -> int:
        """Recursively process all files in directory"""
        total_changes = 0
        
        for file_path in directory.rglob('*'):
            if file_path.is_file() and any(file_path.suffix == ext for ext in self.file_extensions):
                # Skip migration files themselves
                if 'rename_to_production' in str(file_path):
                    continue
                    
                changes = self.rename_in_file(file_path)
                total_changes += changes
        
        return total_changes
    
    def create_production_config(self):
        """Create production configuration file"""
        config_content = '''"""
Production configuration for Instrument Registry
"""
import os
from typing import Optional

# Service identification
SERVICE_NAME = "instrument_registry"
SERVICE_VERSION = "1.0.0"

# Bootstrap configuration (only these should be in environment)
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")
CONFIG_SERVICE_URL = os.getenv("CONFIG_SERVICE_URL", "http://config-service:8080")
INTERNAL_API_KEY = os.getenv("INTERNAL_API_KEY")

# All other config comes from config service
class Config:
    """Production configuration"""
    
    # Database
    DATABASE_URL: str = None
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # Calendar Service
    CALENDAR_SERVICE_URL: str = None
    CALENDAR_SERVICE_API_KEY: str = None
    
    # Message Service
    MESSAGE_SERVICE_URL: str = None
    MESSAGE_SERVICE_API_KEY: str = None
    
    # Event Store
    EVENT_STORE_URL: str = None
    
    # API Configuration
    API_PORT: int = 8084  # From port registry
    API_PREFIX: str = "/api/v1/internal/instrument-registry"
    
    # Ingestion Configuration
    INGESTION_BATCH_SIZE: int = 1000
    INGESTION_WORKER_COUNT: int = 4
    
    # Cache Configuration
    REDIS_URL: str = None
    CACHE_TTL_SECONDS: int = 300
    
    @classmethod
    def load_from_config_service(cls) -> "Config":
        """Load configuration from config service"""
        # Implementation to fetch from config service
        pass
'''
        
        config_path = self.new_dir / "app" / "config_production.py"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(config_content)
        logger.info(f"Created production config at {config_path}")
    
    def remove_mock_config(self):
        """Remove mock configuration file"""
        mock_config = self.new_dir / "app" / "mock_config.py"
        if mock_config.exists():
            mock_config.unlink()
            logger.info("Removed mock_config.py")
    
    def update_ingestion_endpoint(self):
        """Replace stubbed ingestion endpoint with real implementation"""
        api_file = self.new_dir / "app" / "api" / "instrument_registry.py"
        if not api_file.exists():
            return
            
        content = api_file.read_text()
        
        # Replace stub with real implementation
        stub_pattern = r'@router\.post\("/brokers/\{broker_id\}/ingest"\)[\s\S]*?return JSONResponse\([\s\S]*?status_code=501[\s\S]*?\)'
        
        real_implementation = '''@router.post("/brokers/{broker_id}/ingest")
async def ingest_broker_data(
    broker_id: str,
    request: IngestRequest,
    db: AsyncSession = Depends(get_db),
    auth: dict = Depends(verify_internal_token)
):
    """
    Ingest instrument data for a broker
    
    This endpoint queues an ingestion job that will:
    1. Fetch latest instrument catalog from broker
    2. Compare with existing data
    3. Update changed/new instruments
    4. Mark delisted instruments as inactive
    """
    # Verify broker exists
    broker = await db.execute(
        select(BrokerFeed).where(BrokerFeed.broker_id == broker_id)
    )
    broker = broker.scalar_one_or_none()
    
    if not broker:
        raise HTTPException(status_code=404, detail=f"Broker {broker_id} not found")
    
    # Queue ingestion job
    job_id = str(uuid.uuid4())
    ingestion_job = {
        "job_id": job_id,
        "broker_id": broker_id,
        "mode": request.mode,
        "filters": request.filters,
        "created_at": datetime.utcnow().isoformat(),
        "status": "queued"
    }
    
    # Send to job queue (Redis/RabbitMQ/etc)
    await queue_ingestion_job(ingestion_job)
    
    return {
        "job_id": job_id,
        "broker_id": broker_id,
        "status": "queued",
        "message": "Ingestion job queued successfully",
        "estimated_duration_seconds": 300
    }'''
        
        content = re.sub(stub_pattern, real_implementation, content, flags=re.DOTALL)
        api_file.write_text(content)
        logger.info("Updated ingestion endpoint implementation")
    
    def rename_directory(self):
        """Rename the main directory"""
        if self.new_dir.exists():
            logger.warning(f"{self.new_dir} already exists, skipping directory rename")
            return
            
        logger.info(f"Renaming directory {self.old_dir} to {self.new_dir}")
        self.old_dir.rename(self.new_dir)
    
    def run(self):
        """Execute the complete renaming process"""
        logger.info("Starting production rename process")
        
        # Step 1: Create backup
        backup_path = self.backup_directory()
        logger.info(f"Backup created at {backup_path}")
        
        try:
            # Step 2: Rename directory
            self.rename_directory()
            
            # Step 3: Process all files
            total_changes = self.process_directory(self.new_dir)
            logger.info(f"Total changes made: {total_changes}")
            
            # Step 4: Create production config
            self.create_production_config()
            
            # Step 5: Remove mock config
            self.remove_mock_config()
            
            # Step 6: Update ingestion endpoint
            self.update_ingestion_endpoint()
            
            logger.info("Production rename completed successfully")
            
        except Exception as e:
            logger.error(f"Error during rename process: {e}")
            logger.info(f"Restore from backup at {backup_path} if needed")
            raise


def main():
    import argparse
    import time
    
    parser = argparse.ArgumentParser(description="Rename instrument_registry_experiments to production")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be changed without making changes")
    parser.add_argument("--base-path", default="/home/stocksadmin", help="Base path for the service")
    
    args = parser.parse_args()
    
    if args.dry_run:
        logger.info("DRY RUN MODE - No changes will be made")
        # TODO: Implement dry run logic
    else:
        renamer = ProductionRenamer(args.base_path)
        renamer.run()


if __name__ == "__main__":
    main()