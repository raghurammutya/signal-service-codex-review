-- Migration: Copy data from experiments schema to production schema
-- This migrates all existing data while preserving integrity

BEGIN;

-- Migrate broker_feeds
INSERT INTO instrument_registry.broker_feeds
SELECT * FROM instrument_registry_experiments.broker_feeds
ON CONFLICT (broker_id) DO NOTHING;

-- Migrate instrument_keys
INSERT INTO instrument_registry.instrument_keys (
    instrument_key, exchange, segment, series, asset_class, instrument_type,
    symbol, name, isin, strike_price, option_type, expiry_date,
    last_price, tick_size, lot_size, freeze_qty, listing_date,
    metadata, is_active, search_tokens, created_at, updated_at
)
SELECT 
    instrument_key, exchange, segment, series, 
    asset_class::text::instrument_registry.asset_class_enum,
    instrument_type::text::instrument_registry.instrument_type_enum,
    symbol, name, isin, strike_price, 
    option_type::text::instrument_registry.option_type_enum,
    expiry_date, last_price, tick_size, lot_size, freeze_qty, 
    listing_date, metadata, is_active, search_tokens, created_at, updated_at
FROM instrument_registry_experiments.instrument_keys
ON CONFLICT (instrument_key) DO NOTHING;

-- Migrate broker_instrument_tokens
INSERT INTO instrument_registry.broker_instrument_tokens (
    broker_id, instrument_key, broker_token, broker_symbol,
    exchange_token, properties, is_active, created_at, updated_at
)
SELECT 
    broker_id, instrument_key, broker_token, broker_symbol,
    exchange_token, properties, is_active, created_at, updated_at
FROM instrument_registry_experiments.broker_instrument_tokens
ON CONFLICT (broker_id, broker_token) DO NOTHING;

-- Migrate instrument_history_snapshots
INSERT INTO instrument_registry.instrument_history_snapshots
SELECT * FROM instrument_registry_experiments.instrument_history_snapshots
ON CONFLICT (snapshot_date, broker_id) DO NOTHING;

-- Migrate strike_intelligence
INSERT INTO instrument_registry.strike_intelligence (
    underlying_symbol, exchange, option_type, expiry_date,
    base_strike, distance_tier, moneyness_percentage,
    open_interest, volume, implied_volatility, metadata,
    created_at, updated_at
)
SELECT 
    underlying_symbol, exchange, 
    option_type::text::instrument_registry.option_type_enum,
    expiry_date, base_strike,
    distance_tier::text::instrument_registry.distance_tier_enum,
    moneyness_percentage, open_interest, volume,
    implied_volatility, metadata, created_at, updated_at
FROM instrument_registry_experiments.strike_intelligence;

-- Verify row counts match
DO $$
DECLARE
    old_count INTEGER;
    new_count INTEGER;
    table_name TEXT;
BEGIN
    -- Check each table
    FOR table_name IN VALUES 
        ('broker_feeds'),
        ('instrument_keys'),
        ('broker_instrument_tokens'),
        ('instrument_history_snapshots'),
        ('strike_intelligence')
    LOOP
        EXECUTE format('SELECT COUNT(*) FROM instrument_registry_experiments.%I', table_name) INTO old_count;
        EXECUTE format('SELECT COUNT(*) FROM instrument_registry.%I', table_name) INTO new_count;
        
        IF old_count != new_count THEN
            RAISE EXCEPTION 'Row count mismatch for %: old=%, new=%', table_name, old_count, new_count;
        END IF;
        
        RAISE NOTICE 'Migrated % rows in %', new_count, table_name;
    END LOOP;
END;
$$;

-- Create sequences at correct values
SELECT setval(
    'instrument_registry.broker_instrument_tokens_id_seq',
    (SELECT MAX(id) FROM instrument_registry.broker_instrument_tokens)
);

SELECT setval(
    'instrument_registry.instrument_history_snapshots_id_seq',
    (SELECT MAX(id) FROM instrument_registry.instrument_history_snapshots)
);

SELECT setval(
    'instrument_registry.strike_intelligence_id_seq',
    (SELECT MAX(id) FROM instrument_registry.strike_intelligence)
);

COMMIT;