-- Migration: Create production schema for instrument_registry
-- This creates the new schema structure without migrating data

BEGIN;

-- Create new schema
CREATE SCHEMA IF NOT EXISTS instrument_registry;

-- Grant permissions
GRANT USAGE ON SCHEMA instrument_registry TO instrument_registry_app;
GRANT CREATE ON SCHEMA instrument_registry TO instrument_registry_app;

-- Create custom types in new schema
CREATE TYPE instrument_registry.asset_class_enum AS ENUM (
    'EQUITY', 'FUTURES', 'OPTIONS', 'CURRENCY', 'COMMODITY', 'INDEX', 'UNKNOWN'
);

CREATE TYPE instrument_registry.instrument_type_enum AS ENUM (
    'STOCK', 'ETF', 'INDEX', 'FUTURE', 'OPTION', 'CURRENCY_PAIR', 
    'COMMODITY', 'BOND', 'MUTUAL_FUND', 'UNKNOWN'
);

CREATE TYPE instrument_registry.option_type_enum AS ENUM ('CE', 'PE');

CREATE TYPE instrument_registry.ingestion_mode_enum AS ENUM (
    'FULL_CATALOG', 'INCREMENTAL', 'REAL_TIME', 'ON_DEMAND'
);

CREATE TYPE instrument_registry.distance_tier_enum AS ENUM (
    'EXACT_MATCH', 'NEAR_TERM', 'MEDIUM_TERM', 'FAR_TERM', 'DISTANT'
);

-- Create tables with same structure
CREATE TABLE instrument_registry.broker_feeds (
    broker_id VARCHAR(50) PRIMARY KEY,
    broker_name VARCHAR(100) NOT NULL,
    api_endpoint VARCHAR(255),
    auth_type VARCHAR(50),
    auth_credentials JSONB,
    rate_limit_per_minute INTEGER DEFAULT 60,
    max_retries INTEGER DEFAULT 3,
    timeout_seconds INTEGER DEFAULT 30,
    supported_asset_classes instrument_registry.asset_class_enum[] NOT NULL DEFAULT '{}',
    supported_exchanges VARCHAR(10)[] NOT NULL DEFAULT '{}',
    ingestion_schedule JSONB,
    is_active BOOLEAN DEFAULT true,
    last_successful_sync TIMESTAMPTZ,
    config JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT valid_auth_type CHECK (auth_type IN ('api_key', 'oauth2', 'basic', 'custom'))
);

CREATE TABLE instrument_registry.instrument_keys (
    instrument_key VARCHAR(255) PRIMARY KEY,
    exchange VARCHAR(10) NOT NULL,
    segment VARCHAR(10),
    series VARCHAR(10),
    asset_class instrument_registry.asset_class_enum NOT NULL,
    instrument_type instrument_registry.instrument_type_enum NOT NULL,
    symbol VARCHAR(50) NOT NULL,
    name VARCHAR(255),
    isin VARCHAR(12),
    strike_price DECIMAL(20, 4),
    option_type instrument_registry.option_type_enum,
    expiry_date DATE,
    last_price DECIMAL(20, 4),
    tick_size DECIMAL(10, 6) DEFAULT 0.05,
    lot_size INTEGER DEFAULT 1,
    freeze_qty INTEGER,
    listing_date DATE,
    metadata JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    search_tokens TSVECTOR,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT valid_option_fields CHECK (
        (instrument_type != 'OPTION') OR 
        (strike_price IS NOT NULL AND option_type IS NOT NULL AND expiry_date IS NOT NULL)
    )
);

CREATE TABLE instrument_registry.broker_instrument_tokens (
    id BIGSERIAL PRIMARY KEY,
    broker_id VARCHAR(50) NOT NULL,
    instrument_key VARCHAR(255) NOT NULL,
    broker_token VARCHAR(100) NOT NULL,
    broker_symbol VARCHAR(100),
    exchange_token VARCHAR(100),
    properties JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(broker_id, broker_token),
    UNIQUE(broker_id, instrument_key),
    FOREIGN KEY (broker_id) REFERENCES instrument_registry.broker_feeds(broker_id),
    FOREIGN KEY (instrument_key) REFERENCES instrument_registry.instrument_keys(instrument_key)
);

CREATE TABLE instrument_registry.instrument_history_snapshots (
    id BIGSERIAL PRIMARY KEY,
    snapshot_date DATE NOT NULL,
    broker_id VARCHAR(50) NOT NULL,
    instrument_count INTEGER NOT NULL,
    asset_class_breakdown JSONB NOT NULL,
    exchange_breakdown JSONB NOT NULL,
    new_instruments INTEGER DEFAULT 0,
    delisted_instruments INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(snapshot_date, broker_id),
    FOREIGN KEY (broker_id) REFERENCES instrument_registry.broker_feeds(broker_id)
);

CREATE TABLE instrument_registry.strike_intelligence (
    id BIGSERIAL PRIMARY KEY,
    underlying_symbol VARCHAR(50) NOT NULL,
    exchange VARCHAR(10) NOT NULL,
    option_type instrument_registry.option_type_enum NOT NULL,
    expiry_date DATE NOT NULL,
    base_strike DECIMAL(20, 4) NOT NULL,
    distance_tier instrument_registry.distance_tier_enum NOT NULL,
    moneyness_percentage DECIMAL(10, 4) NOT NULL,
    open_interest BIGINT DEFAULT 0,
    volume BIGINT DEFAULT 0,
    implied_volatility DECIMAL(10, 4),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_instrument_keys_exchange ON instrument_registry.instrument_keys(exchange);
CREATE INDEX idx_instrument_keys_symbol ON instrument_registry.instrument_keys(symbol);
CREATE INDEX idx_instrument_keys_asset_class ON instrument_registry.instrument_keys(asset_class);
CREATE INDEX idx_instrument_keys_instrument_type ON instrument_registry.instrument_keys(instrument_type);
CREATE INDEX idx_instrument_keys_expiry_date ON instrument_registry.instrument_keys(expiry_date) 
    WHERE expiry_date IS NOT NULL;
CREATE INDEX idx_instrument_keys_search ON instrument_registry.instrument_keys USING gin(search_tokens);
CREATE INDEX idx_instrument_keys_isin ON instrument_registry.instrument_keys(isin) WHERE isin IS NOT NULL;

CREATE INDEX idx_broker_tokens_broker_id ON instrument_registry.broker_instrument_tokens(broker_id);
CREATE INDEX idx_broker_tokens_instrument_key ON instrument_registry.broker_instrument_tokens(instrument_key);
CREATE INDEX idx_broker_tokens_broker_token ON instrument_registry.broker_instrument_tokens(broker_id, broker_token);

CREATE INDEX idx_history_snapshot_date ON instrument_registry.instrument_history_snapshots(snapshot_date DESC);
CREATE INDEX idx_history_broker_date ON instrument_registry.instrument_history_snapshots(broker_id, snapshot_date DESC);

CREATE INDEX idx_strike_intel_underlying ON instrument_registry.strike_intelligence(underlying_symbol, exchange);
CREATE INDEX idx_strike_intel_expiry ON instrument_registry.strike_intelligence(expiry_date);
CREATE INDEX idx_strike_intel_tier ON instrument_registry.strike_intelligence(distance_tier);

-- Create update trigger function
CREATE OR REPLACE FUNCTION instrument_registry.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers
CREATE TRIGGER update_broker_feeds_updated_at 
    BEFORE UPDATE ON instrument_registry.broker_feeds 
    FOR EACH ROW 
    EXECUTE FUNCTION instrument_registry.update_updated_at_column();

CREATE TRIGGER update_instrument_keys_updated_at 
    BEFORE UPDATE ON instrument_registry.instrument_keys 
    FOR EACH ROW 
    EXECUTE FUNCTION instrument_registry.update_updated_at_column();

CREATE TRIGGER update_broker_tokens_updated_at 
    BEFORE UPDATE ON instrument_registry.broker_instrument_tokens 
    FOR EACH ROW 
    EXECUTE FUNCTION instrument_registry.update_updated_at_column();

CREATE TRIGGER update_strike_intelligence_updated_at 
    BEFORE UPDATE ON instrument_registry.strike_intelligence 
    FOR EACH ROW 
    EXECUTE FUNCTION instrument_registry.update_updated_at_column();

-- Create search token update trigger
CREATE OR REPLACE FUNCTION instrument_registry.update_search_tokens()
RETURNS TRIGGER AS $$
BEGIN
    NEW.search_tokens := to_tsvector('english',
        COALESCE(NEW.symbol, '') || ' ' ||
        COALESCE(NEW.name, '') || ' ' ||
        COALESCE(NEW.exchange, '') || ' ' ||
        COALESCE(NEW.isin, '')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_instrument_search_tokens
    BEFORE INSERT OR UPDATE OF symbol, name, exchange, isin
    ON instrument_registry.instrument_keys
    FOR EACH ROW
    EXECUTE FUNCTION instrument_registry.update_search_tokens();

COMMIT;