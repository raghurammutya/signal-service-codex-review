-- Migration: Set up dual-write triggers for zero-downtime migration
-- This ensures data consistency during the transition period

BEGIN;

-- Function to sync broker_feeds
CREATE OR REPLACE FUNCTION instrument_registry.sync_broker_feeds()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_TABLE_SCHEMA = 'instrument_registry_experiments' THEN
        -- Write to new schema
        IF TG_OP = 'INSERT' THEN
            INSERT INTO instrument_registry.broker_feeds VALUES (NEW.*)
            ON CONFLICT (broker_id) DO UPDATE SET
                broker_name = EXCLUDED.broker_name,
                api_endpoint = EXCLUDED.api_endpoint,
                auth_type = EXCLUDED.auth_type,
                auth_credentials = EXCLUDED.auth_credentials,
                rate_limit_per_minute = EXCLUDED.rate_limit_per_minute,
                max_retries = EXCLUDED.max_retries,
                timeout_seconds = EXCLUDED.timeout_seconds,
                supported_asset_classes = EXCLUDED.supported_asset_classes,
                supported_exchanges = EXCLUDED.supported_exchanges,
                ingestion_schedule = EXCLUDED.ingestion_schedule,
                is_active = EXCLUDED.is_active,
                last_successful_sync = EXCLUDED.last_successful_sync,
                config = EXCLUDED.config,
                updated_at = EXCLUDED.updated_at;
        ELSIF TG_OP = 'UPDATE' THEN
            UPDATE instrument_registry.broker_feeds SET
                broker_name = NEW.broker_name,
                api_endpoint = NEW.api_endpoint,
                auth_type = NEW.auth_type,
                auth_credentials = NEW.auth_credentials,
                rate_limit_per_minute = NEW.rate_limit_per_minute,
                max_retries = NEW.max_retries,
                timeout_seconds = NEW.timeout_seconds,
                supported_asset_classes = NEW.supported_asset_classes,
                supported_exchanges = NEW.supported_exchanges,
                ingestion_schedule = NEW.ingestion_schedule,
                is_active = NEW.is_active,
                last_successful_sync = NEW.last_successful_sync,
                config = NEW.config,
                updated_at = NEW.updated_at
            WHERE broker_id = NEW.broker_id;
        ELSIF TG_OP = 'DELETE' THEN
            DELETE FROM instrument_registry.broker_feeds WHERE broker_id = OLD.broker_id;
        END IF;
    ELSE
        -- Write to old schema
        IF TG_OP = 'INSERT' THEN
            INSERT INTO instrument_registry_experiments.broker_feeds VALUES (NEW.*)
            ON CONFLICT (broker_id) DO UPDATE SET
                broker_name = EXCLUDED.broker_name,
                api_endpoint = EXCLUDED.api_endpoint,
                auth_type = EXCLUDED.auth_type,
                auth_credentials = EXCLUDED.auth_credentials,
                rate_limit_per_minute = EXCLUDED.rate_limit_per_minute,
                max_retries = EXCLUDED.max_retries,
                timeout_seconds = EXCLUDED.timeout_seconds,
                supported_asset_classes = EXCLUDED.supported_asset_classes,
                supported_exchanges = EXCLUDED.supported_exchanges,
                ingestion_schedule = EXCLUDED.ingestion_schedule,
                is_active = EXCLUDED.is_active,
                last_successful_sync = EXCLUDED.last_successful_sync,
                config = EXCLUDED.config,
                updated_at = EXCLUDED.updated_at;
        ELSIF TG_OP = 'UPDATE' THEN
            UPDATE instrument_registry_experiments.broker_feeds SET
                broker_name = NEW.broker_name,
                api_endpoint = NEW.api_endpoint,
                auth_type = NEW.auth_type,
                auth_credentials = NEW.auth_credentials,
                rate_limit_per_minute = NEW.rate_limit_per_minute,
                max_retries = NEW.max_retries,
                timeout_seconds = NEW.timeout_seconds,
                supported_asset_classes = NEW.supported_asset_classes,
                supported_exchanges = NEW.supported_exchanges,
                ingestion_schedule = NEW.ingestion_schedule,
                is_active = NEW.is_active,
                last_successful_sync = NEW.last_successful_sync,
                config = NEW.config,
                updated_at = NEW.updated_at
            WHERE broker_id = NEW.broker_id;
        ELSIF TG_OP = 'DELETE' THEN
            DELETE FROM instrument_registry_experiments.broker_feeds WHERE broker_id = OLD.broker_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to sync instrument_keys
CREATE OR REPLACE FUNCTION instrument_registry.sync_instrument_keys()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_TABLE_SCHEMA = 'instrument_registry_experiments' THEN
        -- Write to new schema
        IF TG_OP = 'INSERT' THEN
            INSERT INTO instrument_registry.instrument_keys VALUES (
                NEW.instrument_key, NEW.exchange, NEW.segment, NEW.series,
                NEW.asset_class::text::instrument_registry.asset_class_enum,
                NEW.instrument_type::text::instrument_registry.instrument_type_enum,
                NEW.symbol, NEW.name, NEW.isin, NEW.strike_price,
                NEW.option_type::text::instrument_registry.option_type_enum,
                NEW.expiry_date, NEW.last_price, NEW.tick_size, NEW.lot_size,
                NEW.freeze_qty, NEW.listing_date, NEW.metadata, NEW.is_active,
                NEW.search_tokens, NEW.created_at, NEW.updated_at
            )
            ON CONFLICT (instrument_key) DO UPDATE SET
                exchange = EXCLUDED.exchange,
                segment = EXCLUDED.segment,
                series = EXCLUDED.series,
                asset_class = EXCLUDED.asset_class,
                instrument_type = EXCLUDED.instrument_type,
                symbol = EXCLUDED.symbol,
                name = EXCLUDED.name,
                isin = EXCLUDED.isin,
                strike_price = EXCLUDED.strike_price,
                option_type = EXCLUDED.option_type,
                expiry_date = EXCLUDED.expiry_date,
                last_price = EXCLUDED.last_price,
                tick_size = EXCLUDED.tick_size,
                lot_size = EXCLUDED.lot_size,
                freeze_qty = EXCLUDED.freeze_qty,
                listing_date = EXCLUDED.listing_date,
                metadata = EXCLUDED.metadata,
                is_active = EXCLUDED.is_active,
                search_tokens = EXCLUDED.search_tokens,
                updated_at = EXCLUDED.updated_at;
        ELSIF TG_OP = 'UPDATE' THEN
            UPDATE instrument_registry.instrument_keys SET
                exchange = NEW.exchange,
                segment = NEW.segment,
                series = NEW.series,
                asset_class = NEW.asset_class::text::instrument_registry.asset_class_enum,
                instrument_type = NEW.instrument_type::text::instrument_registry.instrument_type_enum,
                symbol = NEW.symbol,
                name = NEW.name,
                isin = NEW.isin,
                strike_price = NEW.strike_price,
                option_type = NEW.option_type::text::instrument_registry.option_type_enum,
                expiry_date = NEW.expiry_date,
                last_price = NEW.last_price,
                tick_size = NEW.tick_size,
                lot_size = NEW.lot_size,
                freeze_qty = NEW.freeze_qty,
                listing_date = NEW.listing_date,
                metadata = NEW.metadata,
                is_active = NEW.is_active,
                search_tokens = NEW.search_tokens,
                updated_at = NEW.updated_at
            WHERE instrument_key = NEW.instrument_key;
        ELSIF TG_OP = 'DELETE' THEN
            DELETE FROM instrument_registry.instrument_keys WHERE instrument_key = OLD.instrument_key;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to sync broker_instrument_tokens
CREATE OR REPLACE FUNCTION instrument_registry.sync_broker_tokens()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_TABLE_SCHEMA = 'instrument_registry_experiments' THEN
        -- Write to new schema
        IF TG_OP = 'INSERT' THEN
            INSERT INTO instrument_registry.broker_instrument_tokens 
            VALUES (NEW.*)
            ON CONFLICT (broker_id, broker_token) DO UPDATE SET
                instrument_key = EXCLUDED.instrument_key,
                broker_symbol = EXCLUDED.broker_symbol,
                exchange_token = EXCLUDED.exchange_token,
                properties = EXCLUDED.properties,
                is_active = EXCLUDED.is_active,
                updated_at = EXCLUDED.updated_at;
        ELSIF TG_OP = 'UPDATE' THEN
            UPDATE instrument_registry.broker_instrument_tokens SET
                instrument_key = NEW.instrument_key,
                broker_token = NEW.broker_token,
                broker_symbol = NEW.broker_symbol,
                exchange_token = NEW.exchange_token,
                properties = NEW.properties,
                is_active = NEW.is_active,
                updated_at = NEW.updated_at
            WHERE id = NEW.id;
        ELSIF TG_OP = 'DELETE' THEN
            DELETE FROM instrument_registry.broker_instrument_tokens WHERE id = OLD.id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create dual-write triggers on old schema tables
CREATE TRIGGER dual_write_broker_feeds
    AFTER INSERT OR UPDATE OR DELETE ON instrument_registry_experiments.broker_feeds
    FOR EACH ROW
    EXECUTE FUNCTION instrument_registry.sync_broker_feeds();

CREATE TRIGGER dual_write_instrument_keys
    AFTER INSERT OR UPDATE OR DELETE ON instrument_registry_experiments.instrument_keys
    FOR EACH ROW
    EXECUTE FUNCTION instrument_registry.sync_instrument_keys();

CREATE TRIGGER dual_write_broker_tokens
    AFTER INSERT OR UPDATE OR DELETE ON instrument_registry_experiments.broker_instrument_tokens
    FOR EACH ROW
    EXECUTE FUNCTION instrument_registry.sync_broker_tokens();

-- Add migration tracking table
CREATE TABLE IF NOT EXISTS instrument_registry.migration_status (
    id SERIAL PRIMARY KEY,
    migration_phase VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    metadata JSONB DEFAULT '{}'
);

INSERT INTO instrument_registry.migration_status (migration_phase, status)
VALUES ('dual_write_enabled', 'active');

COMMIT;