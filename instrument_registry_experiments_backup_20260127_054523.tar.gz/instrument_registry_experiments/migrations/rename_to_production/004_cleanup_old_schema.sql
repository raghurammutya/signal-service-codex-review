-- Migration: Cleanup after successful production deployment
-- Only run this after verifying the new schema is working correctly

BEGIN;

-- Remove dual-write triggers
DROP TRIGGER IF EXISTS dual_write_broker_feeds ON instrument_registry_experiments.broker_feeds;
DROP TRIGGER IF EXISTS dual_write_instrument_keys ON instrument_registry_experiments.instrument_keys;
DROP TRIGGER IF EXISTS dual_write_broker_tokens ON instrument_registry_experiments.broker_instrument_tokens;

-- Drop sync functions
DROP FUNCTION IF EXISTS instrument_registry.sync_broker_feeds();
DROP FUNCTION IF EXISTS instrument_registry.sync_instrument_keys();
DROP FUNCTION IF EXISTS instrument_registry.sync_broker_tokens();

-- Update migration status
UPDATE instrument_registry.migration_status 
SET status = 'completed', completed_at = NOW()
WHERE migration_phase = 'dual_write_enabled';

INSERT INTO instrument_registry.migration_status (migration_phase, status)
VALUES ('cleanup_completed', 'active');

-- Create notice about old schema
COMMENT ON SCHEMA instrument_registry_experiments IS 
'DEPRECATED: This schema has been migrated to instrument_registry. Safe to drop after backup verification.';

-- Revoke permissions on old schema
REVOKE ALL ON SCHEMA instrument_registry_experiments FROM instrument_registry_app;
REVOKE ALL ON ALL TABLES IN SCHEMA instrument_registry_experiments FROM instrument_registry_app;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA instrument_registry_experiments FROM instrument_registry_app;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA instrument_registry_experiments FROM instrument_registry_app;

-- Grant full permissions on new schema
GRANT ALL ON SCHEMA instrument_registry TO instrument_registry_app;
GRANT ALL ON ALL TABLES IN SCHEMA instrument_registry TO instrument_registry_app;
GRANT ALL ON ALL SEQUENCES IN SCHEMA instrument_registry TO instrument_registry_app;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA instrument_registry TO instrument_registry_app;

-- Set default search path for application user
ALTER USER instrument_registry_app SET search_path TO instrument_registry, public;

COMMIT;

-- To completely remove old schema (run separately after backup):
-- DROP SCHEMA instrument_registry_experiments CASCADE;