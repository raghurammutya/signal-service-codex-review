-- Instrument token cache for order service proxy

CREATE TABLE IF NOT EXISTS instrument_registry_experiments.instrument_token_cache (
    broker_id TEXT NOT NULL,
    instrument_key TEXT NOT NULL,
    instrument_token TEXT NOT NULL,
    valid_from DATE NOT NULL,
    valid_to DATE,
    lot_size NUMERIC,
    strike NUMERIC,
    metadata JSONB DEFAULT '{}'::JSONB,
    last_refreshed TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (broker_id, instrument_key, valid_from)
);

CREATE INDEX IF NOT EXISTS instrument_registry_experiments.instrument_token_cache_token_idx
    ON instrument_registry_experiments.instrument_token_cache (instrument_token);

CREATE VIEW IF NOT EXISTS instrument_registry_experiments.order_service_instrument_tokens AS
SELECT
    c.broker_id,
    k.symbol,
    k.exchange,
    k.segment,
    k.asset_class,
    k.instrument_type,
    k.instrument_key,
    c.instrument_token,
    c.valid_from,
    c.valid_to,
    c.last_refreshed
FROM instrument_registry_experiments.instrument_token_cache c
JOIN instrument_registry_experiments.instrument_keys k
    ON k.instrument_key = c.instrument_key;

COMMENT ON VIEW instrument_registry_experiments.order_service_instrument_tokens IS
    'Cache view for order_service; exposes cached tokens per broker/instrument';
