-- Instrument Registry Experiment schema + tables
-- This schema is used for prototyping the multi-broker, multi-asset registry

CREATE SCHEMA IF NOT EXISTS instrument_registry_experiments;

CREATE TYPE instrument_registry_experiments.asset_class_enum AS ENUM (
    'equity',
    'future',
    'option',
    'crypto',
    'bond',
    'commodity',
    'other'
);

CREATE TYPE instrument_registry_experiments.instrument_type_enum AS ENUM (
    'EQ',
    'FUT',
    'CE',
    'PE',
    'OPT',
    'CRYPTO',
    'BOND',
    'INDEX',
    'OTHER'
);

CREATE TYPE instrument_registry_experiments.ingestion_mode_enum AS ENUM (
    'api',
    'file',
    'push',
    'manual'
);

CREATE TYPE instrument_registry_experiments.distance_tier_enum AS ENUM (
    'near',
    'mid',
    'far'
);

-- Canonical instrument identity table
CREATE TABLE instrument_registry_experiments.instrument_keys (
    id BIGSERIAL PRIMARY KEY,
    symbol TEXT NOT NULL,
    exchange TEXT NOT NULL,
    segment TEXT,
    country TEXT,
    asset_class instrument_registry_experiments.asset_class_enum NOT NULL,
    instrument_type instrument_registry_experiments.instrument_type_enum NOT NULL,
    asset_subclass TEXT,
    pair_base TEXT,
    pair_quote TEXT,
    quote_currency TEXT,
    settlement_currency TEXT,
    issuer TEXT,
    fund_house TEXT,
    is_pair BOOLEAN DEFAULT FALSE,
    is_mutual_fund BOOLEAN DEFAULT FALSE,
    name TEXT,
    currency TEXT DEFAULT 'INR',
    expiry DATE,
    strike NUMERIC,
    lot_size NUMERIC,
    tick_size NUMERIC,
    underlying_instrument_key_id BIGINT REFERENCES instrument_registry_experiments.instrument_keys ON DELETE SET NULL,
    instrument_key TEXT NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB DEFAULT '{}'::JSONB,
    source_catalog TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS instrument_registry_experiments.instrument_keys_symbol_exchange_idx
    ON instrument_registry_experiments.instrument_keys (symbol, exchange);
CREATE INDEX IF NOT EXISTS instrument_registry_experiments.instrument_keys_asset_expiry_idx
    ON instrument_registry_experiments.instrument_keys (asset_class, expiry);

-- Brokers and ingestion metadata
CREATE TABLE instrument_registry_experiments.broker_feeds (
    broker_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    registry_endpoint TEXT,
    auth_method JSONB,
    ingestion_mode instrument_registry_experiments.ingestion_mode_enum NOT NULL DEFAULT 'api',
    poll_interval_minutes INTEGER DEFAULT 60,
    supported_asset_classes instrument_registry_experiments.asset_class_enum[] DEFAULT ARRAY['equity']::instrument_registry_experiments.asset_class_enum[],
    last_synced_at TIMESTAMPTZ,
    notes TEXT
);

-- Broker-specific tokens linked to canonical instruments
CREATE TABLE instrument_registry_experiments.broker_instrument_tokens (
    id BIGSERIAL PRIMARY KEY,
    broker_id TEXT NOT NULL REFERENCES instrument_registry_experiments.broker_feeds(broker_id) ON DELETE CASCADE,
    instrument_key_id BIGINT NOT NULL REFERENCES instrument_registry_experiments.instrument_keys(id) ON DELETE CASCADE,
    broker_token TEXT NOT NULL,
    valid_from DATE NOT NULL,
    valid_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    source_media TEXT,
    additional_attributes JSONB DEFAULT '{}'::JSONB,
    last_synced_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (broker_id, instrument_key_id, valid_from)
);

CREATE INDEX IF NOT EXISTS instrument_registry_experiments.broker_tokens_key_idx
    ON instrument_registry_experiments.broker_instrument_tokens (instrument_key_id);
CREATE INDEX IF NOT EXISTS instrument_registry_experiments.broker_tokens_broker_idx
    ON instrument_registry_experiments.broker_instrument_tokens (broker_id, broker_token);

-- Historical snapshots for backtests
CREATE TABLE instrument_registry_experiments.instrument_history_snapshots (
    snapshot_date DATE NOT NULL,
    instrument_key_id BIGINT NOT NULL REFERENCES instrument_registry_experiments.instrument_keys(id) ON DELETE CASCADE,
    expiry DATE,
    strike NUMERIC,
    lot_size NUMERIC,
    tick_size NUMERIC,
    metadata JSONB DEFAULT '{}'::JSONB,
    exists BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (snapshot_date, instrument_key_id)
);

-- Strike interval intelligence
CREATE TABLE instrument_registry_experiments.strike_intelligence (
    id BIGSERIAL PRIMARY KEY,
    instrument_key_id BIGINT NOT NULL REFERENCES instrument_registry_experiments.instrument_keys(id) ON DELETE CASCADE,
    expiry_date DATE,
    distance_tier instrument_registry_experiments.distance_tier_enum NOT NULL,
    strike_interval NUMERIC NOT NULL,
    atm_reference NUMERIC,
    density TEXT,
    source_feed TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS instrument_registry_experiments.strike_intelligence_instrument_idx
    ON instrument_registry_experiments.strike_intelligence (instrument_key_id, expiry_date);
